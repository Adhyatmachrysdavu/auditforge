--
-- PostgreSQL database dump
--

\restrict r5p9odc2egFj0KNjgA2kbJKbImERPhikKTKUz9Lzay3X2SscVO0H1yE3utnU0Ad

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: auditforge
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO auditforge;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: auditforge
--

CREATE TABLE public.app_settings (
    key character varying(64) NOT NULL,
    value text,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.app_settings OWNER TO auditforge;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: auditforge
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id integer,
    action character varying(50) NOT NULL,
    method character varying(10) NOT NULL,
    path character varying(300) NOT NULL,
    entity character varying(50),
    entity_id character varying(50),
    status_code integer,
    ip character varying(64),
    detail text,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO auditforge;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: auditforge
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO auditforge;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: auditforge
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: engagement_members; Type: TABLE; Schema: public; Owner: auditforge
--

CREATE TABLE public.engagement_members (
    id integer NOT NULL,
    engagement_id integer NOT NULL,
    user_id integer NOT NULL,
    role_in_team character varying(20) NOT NULL,
    added_by integer,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.engagement_members OWNER TO auditforge;

--
-- Name: engagement_members_id_seq; Type: SEQUENCE; Schema: public; Owner: auditforge
--

CREATE SEQUENCE public.engagement_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.engagement_members_id_seq OWNER TO auditforge;

--
-- Name: engagement_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: auditforge
--

ALTER SEQUENCE public.engagement_members_id_seq OWNED BY public.engagement_members.id;


--
-- Name: engagements; Type: TABLE; Schema: public; Owner: auditforge
--

CREATE TABLE public.engagements (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    client_name character varying(200) NOT NULL,
    description text,
    status character varying(20) NOT NULL,
    created_by integer,
    created_at timestamp with time zone NOT NULL,
    exec_summary_generated boolean DEFAULT false NOT NULL,
    exec_summary_model character varying(64),
    exec_summary_prompt_version character varying(32),
    exec_summary json,
    baseline_hours double precision,
    baseline_note text,
    exec_summary_finding_count integer,
    scope text,
    period_start date,
    period_end date,
    kb_shareable boolean DEFAULT true NOT NULL
);


ALTER TABLE public.engagements OWNER TO auditforge;

--
-- Name: engagements_id_seq; Type: SEQUENCE; Schema: public; Owner: auditforge
--

CREATE SEQUENCE public.engagements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.engagements_id_seq OWNER TO auditforge;

--
-- Name: engagements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: auditforge
--

ALTER SEQUENCE public.engagements_id_seq OWNED BY public.engagements.id;


--
-- Name: finding_attachments; Type: TABLE; Schema: public; Owner: auditforge
--

CREATE TABLE public.finding_attachments (
    id integer NOT NULL,
    finding_id integer NOT NULL,
    filename character varying(255) NOT NULL,
    storage_key character varying(512) NOT NULL,
    content_type character varying(128),
    size integer,
    uploaded_by integer,
    created_at timestamp with time zone
);


ALTER TABLE public.finding_attachments OWNER TO auditforge;

--
-- Name: finding_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: auditforge
--

CREATE SEQUENCE public.finding_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.finding_attachments_id_seq OWNER TO auditforge;

--
-- Name: finding_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: auditforge
--

ALTER SEQUENCE public.finding_attachments_id_seq OWNED BY public.finding_attachments.id;


--
-- Name: finding_revisions; Type: TABLE; Schema: public; Owner: auditforge
--

CREATE TABLE public.finding_revisions (
    id integer NOT NULL,
    finding_id integer NOT NULL,
    action character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    narrative json,
    note text,
    author_id integer,
    created_at timestamp with time zone
);


ALTER TABLE public.finding_revisions OWNER TO auditforge;

--
-- Name: finding_revisions_id_seq; Type: SEQUENCE; Schema: public; Owner: auditforge
--

CREATE SEQUENCE public.finding_revisions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.finding_revisions_id_seq OWNER TO auditforge;

--
-- Name: finding_revisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: auditforge
--

ALTER SEQUENCE public.finding_revisions_id_seq OWNED BY public.finding_revisions.id;


--
-- Name: findings; Type: TABLE; Schema: public; Owner: auditforge
--

CREATE TABLE public.findings (
    id integer NOT NULL,
    engagement_id integer NOT NULL,
    source_upload_id integer,
    title character varying(300) NOT NULL,
    description text,
    severity character varying(10) NOT NULL,
    status character varying(20) NOT NULL,
    cvss_score double precision,
    cwe character varying(32),
    ai_generated boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    fingerprint character varying(64),
    occurrences integer DEFAULT 1 NOT NULL,
    sources json DEFAULT '[]'::json,
    owasp character varying(64),
    cvss_vector character varying(128),
    cve json DEFAULT '[]'::json,
    ai_model character varying(64),
    ai_prompt_version character varying(32),
    ai_draft json,
    priority integer,
    priority_score double precision,
    final_narrative json,
    narrative_edited boolean DEFAULT false NOT NULL,
    reviewed_by integer,
    reviewed_at timestamp with time zone
);


ALTER TABLE public.findings OWNER TO auditforge;

--
-- Name: findings_id_seq; Type: SEQUENCE; Schema: public; Owner: auditforge
--

CREATE SEQUENCE public.findings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.findings_id_seq OWNER TO auditforge;

--
-- Name: findings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: auditforge
--

ALTER SEQUENCE public.findings_id_seq OWNED BY public.findings.id;


--
-- Name: knowledge_entries; Type: TABLE; Schema: public; Owner: auditforge
--

CREATE TABLE public.knowledge_entries (
    id integer NOT NULL,
    source_finding_id integer NOT NULL,
    source_engagement_id integer NOT NULL,
    title character varying(300) NOT NULL,
    title_norm character varying(300) NOT NULL,
    cwe character varying(32),
    owasp character varying(64),
    severity character varying(10) NOT NULL,
    narrative json NOT NULL,
    auditor_edited boolean NOT NULL,
    created_by integer,
    created_at timestamp with time zone NOT NULL,
    usage_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.knowledge_entries OWNER TO auditforge;

--
-- Name: knowledge_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: auditforge
--

CREATE SEQUENCE public.knowledge_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.knowledge_entries_id_seq OWNER TO auditforge;

--
-- Name: knowledge_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: auditforge
--

ALTER SEQUENCE public.knowledge_entries_id_seq OWNED BY public.knowledge_entries.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: auditforge
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    description character varying(255)
);


ALTER TABLE public.roles OWNER TO auditforge;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: auditforge
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO auditforge;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: auditforge
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: scan_uploads; Type: TABLE; Schema: public; Owner: auditforge
--

CREATE TABLE public.scan_uploads (
    id integer NOT NULL,
    engagement_id integer NOT NULL,
    filename character varying(255) NOT NULL,
    tool character varying(20) NOT NULL,
    storage_key character varying(512),
    status character varying(20) NOT NULL,
    uploaded_by integer,
    created_at timestamp with time zone NOT NULL,
    error text,
    content_hash character varying(64)
);


ALTER TABLE public.scan_uploads OWNER TO auditforge;

--
-- Name: scan_uploads_id_seq; Type: SEQUENCE; Schema: public; Owner: auditforge
--

CREATE SEQUENCE public.scan_uploads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scan_uploads_id_seq OWNER TO auditforge;

--
-- Name: scan_uploads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: auditforge
--

ALTER SEQUENCE public.scan_uploads_id_seq OWNED BY public.scan_uploads.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: auditforge
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    full_name character varying(120) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    role_id integer NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.users OWNER TO auditforge;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: auditforge
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO auditforge;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: auditforge
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: engagement_members id; Type: DEFAULT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.engagement_members ALTER COLUMN id SET DEFAULT nextval('public.engagement_members_id_seq'::regclass);


--
-- Name: engagements id; Type: DEFAULT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.engagements ALTER COLUMN id SET DEFAULT nextval('public.engagements_id_seq'::regclass);


--
-- Name: finding_attachments id; Type: DEFAULT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.finding_attachments ALTER COLUMN id SET DEFAULT nextval('public.finding_attachments_id_seq'::regclass);


--
-- Name: finding_revisions id; Type: DEFAULT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.finding_revisions ALTER COLUMN id SET DEFAULT nextval('public.finding_revisions_id_seq'::regclass);


--
-- Name: findings id; Type: DEFAULT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.findings ALTER COLUMN id SET DEFAULT nextval('public.findings_id_seq'::regclass);


--
-- Name: knowledge_entries id; Type: DEFAULT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.knowledge_entries ALTER COLUMN id SET DEFAULT nextval('public.knowledge_entries_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: scan_uploads id; Type: DEFAULT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.scan_uploads ALTER COLUMN id SET DEFAULT nextval('public.scan_uploads_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: auditforge
--

COPY public.alembic_version (version_num) FROM stdin;
d4b7e2c81f95
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: auditforge
--

COPY public.app_settings (key, value, updated_at) FROM stdin;
ai_format	openai	2026-07-28 03:57:42.226006+00
ai_base_url	https://openrouter.ai/api/v1	2026-07-28 03:57:42.226009+00
ai_api_key	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	2026-07-28 04:47:41.437403+00
ai_model	google/gemma-4-26b-a4b-it:free	2026-07-28 05:00:20.621891+00
brand_org_name	PT Suryasoft Konsultama	2026-07-28 09:23:10.312469+00
brand_accent	#0A6E3F	2026-07-28 09:23:10.312472+00
brand_report_title	Laporan Audit Keamanan	2026-07-28 09:23:10.378344+00
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: auditforge
--

COPY public.audit_logs (id, user_id, action, method, path, entity, entity_id, status_code, ip, detail, created_at) FROM stdin;
1	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-27 08:42:40.260178+00
2	1	post	POST	/users	\N	\N	201	172.19.0.1	\N	2026-07-27 08:42:40.606324+00
3	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-27 08:42:40.856228+00
4	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-27 08:45:24.379679+00
5	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-27 08:48:42.197561+00
6	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-27 08:51:33.254615+00
7	1	post	POST	/users	\N	\N	201	172.19.0.1	\N	2026-07-27 08:53:57.964966+00
8	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-27 08:55:10.579025+00
9	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-27 09:06:02.009456+00
10	1	post	POST	/engagements	\N	\N	201	172.19.0.1	\N	2026-07-27 09:06:02.101836+00
11	1	post	POST	/engagements/1/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 09:06:02.281054+00
12	1	post	POST	/engagements/1/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 09:06:02.337273+00
13	\N	post	POST	/auth/login	\N	\N	401	172.19.0.1	\N	2026-07-27 09:18:09.372622+00
14	\N	post	POST	/auth/login	\N	\N	401	172.19.0.1	\N	2026-07-27 09:18:51.381225+00
15	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-27 09:19:05.900102+00
16	1	post	POST	/engagements	\N	\N	201	172.19.0.1	\N	2026-07-27 09:19:36.873431+00
17	1	post	POST	/engagements/2/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 09:22:04.570054+00
18	1	post	POST	/engagements/2/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 09:32:12.896306+00
51	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-27 14:45:36.0097+00
52	1	post	POST	/engagements	\N	\N	201	172.19.0.1	\N	2026-07-27 14:45:36.090575+00
53	1	post	POST	/engagements/3/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 14:45:36.210299+00
54	1	post	POST	/engagements/3/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 14:45:36.265073+00
55	1	post	POST	/engagements/3/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 14:45:36.323313+00
56	1	post	POST	/engagements/3/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 14:45:36.38274+00
57	1	post	POST	/engagements/3/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 14:45:36.441947+00
58	\N	post	POST	/engagements	\N	\N	401	172.19.0.1	\N	2026-07-27 14:51:54.919616+00
59	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-27 14:52:38.517359+00
60	1	post	POST	/engagements	\N	\N	201	172.19.0.1	\N	2026-07-27 14:52:46.019867+00
61	1	post	POST	/engagements/4/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 14:53:49.946188+00
62	1	post	POST	/engagements/4/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 14:54:03.779561+00
63	1	post	POST	/engagements/4/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 14:54:21.648587+00
64	1	post	POST	/engagements/4/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 14:54:59.727667+00
65	1	post	POST	/engagements/4/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 14:55:34.732434+00
66	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-27 15:15:13.082006+00
67	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-27 15:16:58.156204+00
68	1	post	POST	/engagements	\N	\N	201	172.19.0.1	\N	2026-07-27 15:18:16.584254+00
69	1	post	POST	/engagements/5/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 15:21:39.291246+00
70	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-27 15:23:08.576522+00
71	1	post	POST	/engagements/5/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 15:24:18.642347+00
72	1	post	POST	/engagements/5/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 15:25:23.045417+00
73	1	post	POST	/engagements/5/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 15:25:39.144704+00
74	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-27 15:29:19.418309+00
75	1	post	POST	/engagements	\N	\N	201	172.19.0.1	\N	2026-07-27 15:29:19.619448+00
76	1	post	POST	/engagements/6/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 15:29:19.752577+00
77	1	post	POST	/engagements/6/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 15:29:19.799562+00
78	1	post	POST	/engagements/6/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 15:29:19.846822+00
79	1	post	POST	/engagements/6/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 15:29:19.894761+00
80	1	post	POST	/engagements/6/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 15:29:19.941559+00
81	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-27 15:31:55.600352+00
82	1	post	POST	/engagements	\N	\N	201	172.19.0.1	\N	2026-07-27 15:32:55.909207+00
83	1	post	POST	/engagements/7/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 15:33:13.467094+00
84	1	post	POST	/engagements/1/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 15:55:26.012684+00
85	1	post	POST	/engagements/1/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 15:55:39.93426+00
86	1	post	POST	/engagements/1/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 15:55:51.277367+00
87	1	post	POST	/engagements/1/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 15:55:57.282996+00
88	1	post	POST	/engagements/1/uploads	\N	\N	201	172.19.0.1	\N	2026-07-27 15:56:03.675751+00
117	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 01:06:44.609026+00
118	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 01:23:25.700705+00
119	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 01:24:24.147314+00
120	1	post	POST	/engagements/7/uploads	\N	\N	201	172.19.0.1	\N	2026-07-28 01:24:46.245563+00
121	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 02:06:02.676705+00
122	1	post	POST	/engagements	\N	\N	201	172.19.0.1	\N	2026-07-28 02:06:02.753436+00
123	1	post	POST	/engagements/8/uploads	\N	\N	201	172.19.0.1	\N	2026-07-28 02:06:02.866668+00
124	1	post	POST	/engagements/8/uploads	\N	\N	201	172.19.0.1	\N	2026-07-28 02:06:05.939229+00
125	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 02:06:56.175783+00
126	1	post	POST	/engagements/8/uploads	\N	\N	201	172.19.0.1	\N	2026-07-28 02:06:56.243814+00
127	1	post	POST	/engagements	\N	\N	201	172.19.0.1	\N	2026-07-28 02:26:56.793491+00
128	1	post	POST	/engagements/9/uploads	\N	\N	201	172.19.0.1	\N	2026-07-28 02:28:00.81791+00
129	1	post	POST	/engagements/9/uploads	\N	\N	201	172.19.0.1	\N	2026-07-28 02:28:28.660353+00
130	1	post	POST	/engagements/9/uploads	\N	\N	201	172.19.0.1	\N	2026-07-28 02:29:05.151087+00
131	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 02:34:57.655211+00
132	1	post	POST	/engagements	\N	\N	201	172.19.0.1	\N	2026-07-28 02:34:57.734788+00
133	1	post	POST	/engagements/10/uploads	\N	\N	201	172.19.0.1	\N	2026-07-28 02:34:57.844686+00
134	1	post	POST	/engagements	\N	\N	201	172.19.0.1	\N	2026-07-28 02:49:04.723006+00
135	1	post	POST	/engagements/11/uploads	\N	\N	201	172.19.0.1	\N	2026-07-28 02:52:00.60579+00
136	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 03:43:06.717449+00
137	1	post	POST	/admin/llm/test	\N	\N	200	172.19.0.1	\N	2026-07-28 03:43:08.238594+00
138	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 03:43:34.072383+00
139	1	put	PUT	/admin/llm	\N	\N	200	172.19.0.1	\N	2026-07-28 03:43:34.133916+00
140	1	put	PUT	/admin/llm	\N	\N	200	172.19.0.1	\N	2026-07-28 03:57:42.235688+00
141	1	put	PUT	/admin/llm	\N	\N	200	172.19.0.1	\N	2026-07-28 03:59:47.123861+00
142	1	post	POST	/admin/llm/test	\N	\N	200	172.19.0.1	\N	2026-07-28 03:59:49.171148+00
143	1	put	PUT	/admin/llm	\N	\N	200	172.19.0.1	\N	2026-07-28 04:00:22.095291+00
144	1	post	POST	/admin/llm/test	\N	\N	200	172.19.0.1	\N	2026-07-28 04:00:25.087942+00
145	1	put	PUT	/admin/llm	\N	\N	200	172.19.0.1	\N	2026-07-28 04:00:37.085777+00
147	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 04:02:04.498666+00
149	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 04:02:04.80987+00
151	1	post	POST	/users	\N	\N	409	172.19.0.1	\N	2026-07-28 04:03:31.99551+00
154	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 04:04:12.406517+00
155	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 04:11:25.407013+00
146	1	post	POST	/admin/llm/test	\N	\N	200	172.19.0.1	\N	2026-07-28 04:00:39.655372+00
148	1	post	POST	/users	\N	\N	409	172.19.0.1	\N	2026-07-28 04:02:04.558855+00
150	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 04:03:31.94961+00
152	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 04:03:53.237201+00
153	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 04:03:53.547142+00
156	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 04:18:23.672324+00
157	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 04:18:33.406588+00
158	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 04:24:10.818937+00
159	1	post	POST	/engagements	\N	\N	201	172.19.0.1	\N	2026-07-28 04:24:10.911568+00
160	1	post	POST	/engagements/12/uploads	\N	\N	201	172.19.0.1	\N	2026-07-28 04:24:11.11341+00
161	1	post	POST	/engagements/12/generate-narratives	\N	\N	200	172.19.0.1	\N	2026-07-28 04:24:15.344626+00
162	1	put	PUT	/admin/llm	\N	\N	200	172.19.0.1	\N	2026-07-28 04:47:41.458817+00
163	1	post	POST	/admin/llm/test	\N	\N	200	172.19.0.1	\N	2026-07-28 04:47:47.538654+00
164	1	post	POST	/engagements	\N	\N	201	172.19.0.1	\N	2026-07-28 04:51:24.314626+00
165	1	post	POST	/engagements/13/uploads	\N	\N	201	172.19.0.1	\N	2026-07-28 04:51:42.033123+00
166	1	post	POST	/engagements/13/generate-narratives	\N	\N	200	172.19.0.1	\N	2026-07-28 04:51:51.13977+00
167	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 05:03:05.213507+00
168	1	post	POST	/engagements	\N	\N	201	172.19.0.1	\N	2026-07-28 05:03:05.295653+00
169	1	post	POST	/engagements/14/uploads	\N	\N	201	172.19.0.1	\N	2026-07-28 05:03:05.425592+00
170	1	post	POST	/engagements/14/generate-narratives	\N	\N	200	172.19.0.1	\N	2026-07-28 05:03:09.502137+00
171	1	post	POST	/engagements	\N	\N	201	172.19.0.1	\N	2026-07-28 06:08:35.765577+00
172	1	post	POST	/engagements/15/uploads	\N	\N	201	172.19.0.1	\N	2026-07-28 06:08:45.729755+00
173	1	post	POST	/engagements/15/generate-narratives	\N	\N	200	172.19.0.1	\N	2026-07-28 06:08:53.644363+00
174	1	post	POST	/engagements	\N	\N	201	172.19.0.1	\N	2026-07-28 06:14:02.361324+00
175	1	post	POST	/engagements/16/uploads	\N	\N	201	172.19.0.1	\N	2026-07-28 06:14:14.480873+00
176	1	post	POST	/engagements/16/generate-narratives	\N	\N	200	172.19.0.1	\N	2026-07-28 06:14:18.145755+00
177	\N	post	POST	/auth/login	\N	\N	200	127.0.0.1	\N	2026-07-28 06:35:42.625139+00
178	1	post	POST	/engagements/1/triage	\N	\N	200	127.0.0.1	\N	2026-07-28 06:35:42.664701+00
179	\N	post	POST	/auth/login	\N	\N	200	127.0.0.1	\N	2026-07-28 06:36:00.656549+00
180	1	post	POST	/engagements/1/exec-summary	\N	\N	200	127.0.0.1	\N	2026-07-28 06:36:00.773736+00
181	1	post	POST	/engagements/15/triage	\N	\N	200	172.19.0.1	\N	2026-07-28 07:02:15.711164+00
182	1	post	POST	/engagements/9/triage	\N	\N	200	172.19.0.1	\N	2026-07-28 07:04:02.831654+00
183	1	post	POST	/engagements/16/exec-summary	\N	\N	200	172.19.0.1	\N	2026-07-28 07:04:40.997534+00
184	1	post	POST	/engagements/16/triage	\N	\N	200	172.19.0.1	\N	2026-07-28 07:04:47.32844+00
185	1	post	POST	/engagements/16/exec-summary	\N	\N	200	172.19.0.1	\N	2026-07-28 07:05:15.298325+00
186	1	post	POST	/engagements/16/exec-summary	\N	\N	200	172.19.0.1	\N	2026-07-28 07:05:19.388709+00
187	1	post	POST	/engagements/16/exec-summary	\N	\N	200	172.19.0.1	\N	2026-07-28 07:05:27.277177+00
188	1	post	POST	/engagements/16/exec-summary	\N	\N	200	172.19.0.1	\N	2026-07-28 07:05:37.628294+00
189	1	post	POST	/engagements/16/exec-summary	\N	\N	200	172.19.0.1	\N	2026-07-28 07:05:48.277683+00
190	\N	post	POST	/auth/login	\N	\N	200	127.0.0.1	\N	2026-07-28 07:50:29.011104+00
191	1	put	PUT	/engagements/1/findings/1/narrative	\N	\N	200	127.0.0.1	\N	2026-07-28 07:50:29.067227+00
192	1	post	POST	/engagements/1/findings/1/status	\N	\N	200	127.0.0.1	\N	2026-07-28 07:50:29.09549+00
193	1	post	POST	/engagements/1/findings/1/status	\N	\N	200	127.0.0.1	\N	2026-07-28 07:50:29.117989+00
194	1	post	POST	/engagements/1/findings/1/status	\N	\N	409	127.0.0.1	\N	2026-07-28 07:50:29.153327+00
195	\N	post	POST	/auth/login	\N	\N	401	127.0.0.1	\N	2026-07-28 07:50:55.346351+00
196	\N	post	POST	/auth/login	\N	\N	401	127.0.0.1	\N	2026-07-28 07:50:55.565826+00
197	\N	post	POST	/auth/login	\N	\N	200	127.0.0.1	\N	2026-07-28 07:51:28.284268+00
198	1	post	POST	/users	\N	\N	201	127.0.0.1	\N	2026-07-28 07:51:28.517316+00
199	1	post	POST	/users	\N	\N	201	127.0.0.1	\N	2026-07-28 07:51:28.728062+00
200	\N	post	POST	/auth/login	\N	\N	200	127.0.0.1	\N	2026-07-28 07:51:28.934455+00
201	\N	post	POST	/auth/login	\N	\N	200	127.0.0.1	\N	2026-07-28 07:51:29.142797+00
202	4	post	POST	/engagements/1/findings/3/status	\N	\N	200	127.0.0.1	\N	2026-07-28 07:51:29.21626+00
203	4	post	POST	/engagements/1/findings/3/status	\N	\N	403	127.0.0.1	\N	2026-07-28 07:51:29.231941+00
204	5	post	POST	/engagements/1/findings/3/status	\N	\N	200	127.0.0.1	\N	2026-07-28 07:51:29.248723+00
205	4	put	PUT	/engagements/1/findings/3/narrative	\N	\N	200	127.0.0.1	\N	2026-07-28 07:51:29.265142+00
206	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 07:59:20.064744+00
207	2	post	POST	/engagements/1/findings/83/status	\N	\N	200	172.19.0.1	\N	2026-07-28 08:02:55.519944+00
208	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 08:05:11.805988+00
209	3	post	POST	/engagements/1/findings/83/status	\N	\N	200	172.19.0.1	\N	2026-07-28 08:05:49.216605+00
210	3	post	POST	/engagements/1/findings/83/status	\N	\N	200	172.19.0.1	\N	2026-07-28 08:06:26.09714+00
211	3	post	POST	/engagements/1/findings/92/status	\N	\N	200	172.19.0.1	\N	2026-07-28 08:08:48.978232+00
212	3	post	POST	/engagements/1/findings/92/status	\N	\N	200	172.19.0.1	\N	2026-07-28 08:08:50.501637+00
213	3	post	POST	/engagements/1/findings/92/status	\N	\N	200	172.19.0.1	\N	2026-07-28 08:08:52.113999+00
214	3	post	POST	/engagements/1/findings/92/status	\N	\N	200	172.19.0.1	\N	2026-07-28 08:08:54.399488+00
215	3	post	POST	/engagements/1/findings/92/status	\N	\N	200	172.19.0.1	\N	2026-07-28 08:08:56.039855+00
216	3	post	POST	/engagements/1/findings/92/status	\N	\N	200	172.19.0.1	\N	2026-07-28 08:08:56.967155+00
217	\N	post	POST	/auth/login	\N	\N	200	127.0.0.1	\N	2026-07-28 08:36:26.546885+00
218	1	post	POST	/engagements/1/findings/1/attachments	\N	\N	201	127.0.0.1	\N	2026-07-28 08:36:26.634159+00
219	1	delete	DELETE	/engagements/1/findings/1/attachments/1	\N	\N	204	127.0.0.1	\N	2026-07-28 08:36:26.685961+00
220	\N	post	POST	/auth/login	\N	\N	200	127.0.0.1	\N	2026-07-28 08:44:58.781468+00
221	1	post	POST	/engagements/1/findings/4/status	\N	\N	200	127.0.0.1	\N	2026-07-28 08:44:58.861753+00
222	1	post	POST	/engagements/1/findings/4/status	\N	\N	200	127.0.0.1	\N	2026-07-28 08:44:58.880589+00
223	1	post	POST	/engagements/1/findings/4/attachments	\N	\N	201	127.0.0.1	\N	2026-07-28 08:44:58.924323+00
224	1	delete	DELETE	/engagements/1/findings/4/attachments/2	\N	\N	204	127.0.0.1	\N	2026-07-28 08:44:58.942564+00
225	\N	post	POST	/auth/login	\N	\N	401	172.19.0.1	\N	2026-07-28 08:51:09.650179+00
226	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-28 08:51:14.775314+00
227	1	post	POST	/engagements/1/findings/5/status	\N	\N	200	172.19.0.1	\N	2026-07-28 08:54:54.4397+00
228	1	post	POST	/engagements/1/findings/5/status	\N	\N	200	172.19.0.1	\N	2026-07-28 08:54:57.046384+00
229	1	post	POST	/engagements/1/findings/92/status	\N	\N	409	172.19.0.1	\N	2026-07-28 08:55:00.117199+00
230	1	post	POST	/engagements/1/findings/92/status	\N	\N	200	172.19.0.1	\N	2026-07-28 08:55:04.658463+00
233	1	post	POST	/engagements/1/findings/92/status	\N	\N	200	172.19.0.1	\N	2026-07-28 08:55:10.923807+00
231	1	post	POST	/engagements/1/findings/92/status	\N	\N	200	172.19.0.1	\N	2026-07-28 08:55:05.928891+00
232	1	post	POST	/engagements/1/findings/85/status	\N	\N	409	172.19.0.1	\N	2026-07-28 08:55:07.312065+00
234	1	post	POST	/engagements/1/generate-narratives	\N	\N	200	172.19.0.1	\N	2026-07-28 08:58:21.886195+00
235	1	post	POST	/engagements/1/findings/83/status	\N	\N	200	172.19.0.1	\N	2026-07-28 08:58:59.287356+00
236	1	post	POST	/engagements/1/findings/83/status	\N	\N	200	172.19.0.1	\N	2026-07-28 08:59:04.767979+00
237	1	post	POST	/engagements/1/findings/83/status	\N	\N	200	172.19.0.1	\N	2026-07-28 08:59:10.543436+00
238	1	post	POST	/engagements/1/generate-narratives	\N	\N	200	172.19.0.1	\N	2026-07-28 08:59:21.498823+00
239	1	post	POST	/engagements/1/generate-narratives	\N	\N	200	172.19.0.1	\N	2026-07-28 08:59:33.796928+00
240	1	post	POST	/engagements/16/findings/142/attachments	\N	\N	201	172.19.0.1	\N	2026-07-28 09:04:26.398796+00
241	1	delete	DELETE	/engagements/16/findings/142/attachments/3	\N	\N	204	172.19.0.1	\N	2026-07-28 09:04:36.850324+00
242	\N	post	POST	/auth/login	\N	\N	200	127.0.0.1	\N	2026-07-28 09:15:57.967452+00
243	\N	post	POST	/auth/login	\N	\N	200	127.0.0.1	\N	2026-07-28 09:23:10.277888+00
244	1	put	PUT	/admin/branding	\N	\N	200	127.0.0.1	\N	2026-07-28 09:23:10.320205+00
245	1	put	PUT	/admin/branding	\N	\N	200	127.0.0.1	\N	2026-07-28 09:23:10.386032+00
246	1	put	PUT	/admin/branding	\N	\N	200	172.19.0.1	\N	2026-07-28 09:28:54.42631+00
247	\N	post	POST	/auth/login	\N	\N	200	127.0.0.1	\N	2026-07-28 09:40:18.774573+00
248	1	post	POST	/engagements/1/findings/3/attachments	\N	\N	201	172.19.0.1	\N	2026-07-28 09:56:16.222033+00
249	\N	post	POST	/auth/login	\N	\N	200	127.0.0.1	\N	2026-07-30 01:36:38.082558+00
250	1	post	POST	/admin/masking-preview	\N	\N	200	127.0.0.1	\N	2026-07-30 01:36:38.230253+00
251	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-30 01:44:50.495423+00
252	1	post	POST	/admin/masking-preview	\N	\N	200	172.19.0.1	\N	2026-07-30 01:55:33.58197+00
253	1	post	POST	/admin/masking-preview	\N	\N	200	172.19.0.1	\N	2026-07-30 01:55:58.128439+00
254	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-30 02:30:31.125894+00
255	1	post	POST	/engagements/1/generate-narratives	\N	\N	200	172.19.0.1	\N	2026-07-30 02:41:44.856364+00
256	1	post	POST	/admin/masking-preview	\N	\N	200	172.19.0.1	\N	2026-07-30 02:43:47.88333+00
257	\N	post	POST	/auth/login	\N	\N	401	172.19.0.1	\N	2026-07-30 02:57:24.322986+00
258	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-30 02:57:30.18124+00
259	\N	post	POST	/auth/login	\N	\N	422	172.19.0.1	\N	2026-07-30 06:17:53.979002+00
260	\N	post	POST	/auth/login	\N	\N	422	172.19.0.1	\N	2026-07-30 06:17:54.027322+00
261	\N	post	POST	/auth/login	\N	\N	422	172.19.0.1	\N	2026-07-30 06:17:54.064095+00
262	\N	post	POST	/auth/login	\N	\N	422	172.19.0.1	\N	2026-07-30 06:17:54.102239+00
263	\N	post	POST	/auth/login	\N	\N	422	172.19.0.1	\N	2026-07-30 06:17:54.147107+00
264	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-30 06:19:49.185737+00
265	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-30 06:19:49.435762+00
266	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-30 06:19:49.666604+00
267	\N	post	POST	/auth/login	\N	\N	401	172.19.0.1	\N	2026-07-30 06:19:49.895109+00
268	\N	post	POST	/auth/login	\N	\N	401	172.19.0.1	\N	2026-07-30 06:19:50.121432+00
269	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-30 06:19:50.384658+00
270	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-07-30 06:19:50.608301+00
271	\N	post	POST	/auth/login	\N	\N	401	172.19.0.8	\N	2026-08-03 01:36:20.272232+00
272	\N	post	POST	/auth/login	\N	\N	200	172.19.0.8	\N	2026-08-03 01:36:26.967161+00
273	1	post	POST	/engagements	\N	\N	201	172.19.0.8	\N	2026-08-03 01:44:52.326147+00
274	1	post	POST	/engagements/17/uploads	\N	\N	201	172.19.0.8	\N	2026-08-03 01:45:40.221375+00
275	1	post	POST	/engagements/17/findings/155/status	\N	\N	200	172.19.0.8	\N	2026-08-03 01:46:08.952304+00
276	1	post	POST	/engagements/17/generate-narratives	\N	\N	200	172.19.0.8	\N	2026-08-03 01:46:21.110023+00
277	1	post	POST	/engagements/17/triage	\N	\N	200	172.19.0.8	\N	2026-08-03 01:47:27.537204+00
278	1	post	POST	/engagements/17/exec-summary	\N	\N	200	172.19.0.8	\N	2026-08-03 01:47:39.460403+00
279	1	post	POST	/admin/masking-preview	\N	\N	200	172.19.0.8	\N	2026-08-03 01:51:17.653075+00
280	1	post	POST	/engagements/17/uploads	\N	\N	201	172.19.0.8	\N	2026-08-03 01:53:16.429257+00
281	1	post	POST	/engagements/17/generate-narratives	\N	\N	200	172.19.0.8	\N	2026-08-03 01:53:21.918444+00
282	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-03 07:57:46.800729+00
283	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-03 07:57:56.914989+00
284	1	put	PUT	/engagements/17/baseline	\N	\N	200	172.19.0.1	\N	2026-08-03 07:57:57.074379+00
285	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-03 08:02:18.485451+00
286	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-03 08:04:05.302195+00
287	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-03 08:04:13.302939+00
288	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-03 08:07:22.706378+00
289	\N	post	POST	/auth/login	\N	\N	422	172.19.0.8	\N	2026-08-03 08:10:17.715788+00
290	\N	post	POST	/auth/login	\N	\N	200	172.19.0.8	\N	2026-08-03 08:10:33.896975+00
291	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-03 08:28:25.391637+00
292	1	put	PUT	/engagements/17/baseline	\N	\N	200	172.19.0.1	\N	2026-08-03 08:28:37.963697+00
293	1	put	PUT	/engagements/2/baseline	\N	\N	200	172.19.0.1	\N	2026-08-03 08:34:33.164431+00
294	1	put	PUT	/engagements/2/baseline	\N	\N	200	172.19.0.1	\N	2026-08-03 08:34:33.37454+00
295	\N	post	POST	/auth/login	\N	\N	401	172.19.0.1	\N	2026-08-03 08:37:37.735663+00
296	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-03 08:37:38.024451+00
297	2	put	PUT	/engagements/17/baseline	\N	\N	403	172.19.0.1	\N	2026-08-03 08:37:38.198409+00
298	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-03 08:45:58.708925+00
299	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-03 08:46:19.80375+00
300	1	put	PUT	/engagements/2/baseline	\N	\N	200	172.19.0.1	\N	2026-08-03 08:46:19.896172+00
301	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-03 08:46:51.004332+00
302	1	put	PUT	/engagements/2/baseline	\N	\N	200	172.19.0.1	\N	2026-08-03 08:46:51.079809+00
303	\N	post	POST	/auth/login	\N	\N	200	172.19.0.8	\N	2026-08-04 01:59:30.294043+00
304	1	post	POST	/engagements/17/triage	\N	\N	200	172.19.0.8	\N	2026-08-04 02:13:38.866097+00
305	1	post	POST	/engagements/17/findings/158/status	\N	\N	200	172.19.0.8	\N	2026-08-04 02:17:01.397409+00
306	1	post	POST	/engagements/17/findings/158/status	\N	\N	200	172.19.0.8	\N	2026-08-04 02:17:02.756713+00
307	1	post	POST	/engagements/17/findings/155/status	\N	\N	200	172.19.0.8	\N	2026-08-04 02:17:17.241836+00
308	1	post	POST	/engagements/17/findings/157/status	\N	\N	200	172.19.0.8	\N	2026-08-04 02:17:29.186684+00
309	1	post	POST	/engagements/17/findings/157/status	\N	\N	200	172.19.0.8	\N	2026-08-04 02:17:30.451858+00
310	1	put	PUT	/engagements/17/baseline	\N	\N	200	172.19.0.8	\N	2026-08-04 02:40:52.273672+00
311	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 02:42:10.06932+00
312	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 02:52:04.573433+00
313	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 03:01:11.925731+00
314	1	put	PUT	/engagements/17/findings/158/narrative	\N	\N	200	172.19.0.8	\N	2026-08-04 03:06:48.847689+00
315	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 03:08:54.039912+00
316	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 03:38:51.609066+00
317	1	post	POST	/engagements/17/uploads	\N	\N	201	172.19.0.1	\N	2026-08-04 03:38:51.866783+00
318	1	post	POST	/engagements/17/uploads	\N	\N	409	172.19.0.1	\N	2026-08-04 03:39:08.601858+00
319	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 03:44:44.760583+00
320	1	post	POST	/engagements/17/uploads/110/reparse	\N	\N	409	172.19.0.1	\N	2026-08-04 03:44:44.9388+00
321	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 03:44:56.17781+00
322	1	post	POST	/engagements/17/uploads/110/reparse	\N	\N	200	172.19.0.1	\N	2026-08-04 03:44:56.425299+00
323	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 03:48:24.63584+00
324	1	post	POST	/engagements/17/uploads/110/reparse	\N	\N	409	172.19.0.1	\N	2026-08-04 03:48:24.749477+00
325	1	post	POST	/engagements/17/uploads/40/reparse	\N	\N	404	172.19.0.1	\N	2026-08-04 03:48:24.827526+00
326	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 03:50:16.076803+00
327	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 03:53:25.138596+00
328	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 04:23:36.646913+00
329	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 04:23:51.322478+00
330	1	post	POST	/engagements/17/uploads/109/reparse	\N	\N	409	172.19.0.1	\N	2026-08-04 04:23:51.601616+00
331	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 04:24:06.978769+00
332	1	post	POST	/engagements/17/uploads/109/reparse	\N	\N	409	172.19.0.1	\N	2026-08-04 04:24:07.071408+00
333	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 04:24:20.513504+00
334	1	post	POST	/engagements/17/uploads/109/reparse	\N	\N	200	172.19.0.1	\N	2026-08-04 04:24:20.771563+00
335	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 04:24:41.368138+00
336	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 04:24:52.407794+00
337	1	post	POST	/engagements/17/uploads	\N	\N	409	172.19.0.1	\N	2026-08-04 04:24:52.533881+00
338	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 04:33:02.121837+00
339	1	post	POST	/engagements/17/uploads/109/reparse	\N	\N	409	172.19.0.1	\N	2026-08-04 04:33:02.268847+00
340	1	post	POST	/engagements/17/uploads/109/reparse	\N	\N	200	172.19.0.8	\N	2026-08-04 04:41:57.321362+00
341	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 04:45:08.944437+00
342	1	post	POST	/engagements/17/uploads	\N	\N	201	172.19.0.1	\N	2026-08-04 04:45:09.273297+00
343	1	post	POST	/engagements	\N	\N	201	172.19.0.8	\N	2026-08-04 06:08:59.89343+00
344	1	post	POST	/engagements/18/uploads	\N	\N	201	172.19.0.8	\N	2026-08-04 06:10:24.886716+00
345	1	post	POST	/engagements/18/uploads	\N	\N	201	172.19.0.8	\N	2026-08-04 06:10:31.182871+00
346	1	post	POST	/engagements/18/uploads	\N	\N	201	172.19.0.8	\N	2026-08-04 06:11:00.292138+00
347	1	post	POST	/engagements/18/uploads	\N	\N	409	172.19.0.8	\N	2026-08-04 06:11:11.510339+00
348	1	post	POST	/engagements/18/generate-narratives	\N	\N	200	172.19.0.8	\N	2026-08-04 06:11:36.480121+00
349	1	post	POST	/engagements/18/findings/165/status	\N	\N	200	172.19.0.8	\N	2026-08-04 06:12:58.981163+00
350	1	post	POST	/engagements/18/findings/165/status	\N	\N	200	172.19.0.8	\N	2026-08-04 06:12:59.92975+00
351	1	post	POST	/engagements/18/findings/167/status	\N	\N	200	172.19.0.8	\N	2026-08-04 06:13:04.11524+00
352	1	post	POST	/engagements/18/findings/167/status	\N	\N	200	172.19.0.8	\N	2026-08-04 06:13:05.060799+00
353	1	post	POST	/engagements/18/findings/164/status	\N	\N	200	172.19.0.8	\N	2026-08-04 06:13:08.376368+00
354	1	post	POST	/engagements/18/findings/164/status	\N	\N	200	172.19.0.8	\N	2026-08-04 06:13:10.994431+00
355	1	post	POST	/engagements/18/findings/163/status	\N	\N	200	172.19.0.8	\N	2026-08-04 06:13:14.513124+00
356	1	post	POST	/engagements/18/findings/163/status	\N	\N	200	172.19.0.8	\N	2026-08-04 06:13:16.365065+00
357	1	post	POST	/engagements/18/findings/166/status	\N	\N	200	172.19.0.8	\N	2026-08-04 06:13:20.266375+00
358	1	post	POST	/engagements/18/findings/166/status	\N	\N	200	172.19.0.8	\N	2026-08-04 06:13:21.312993+00
359	1	post	POST	/engagements/18/exec-summary	\N	\N	200	172.19.0.8	\N	2026-08-04 06:13:35.280505+00
360	1	put	PUT	/engagements/18/findings/165/narrative	\N	\N	200	172.19.0.8	\N	2026-08-04 06:26:13.264783+00
361	1	put	PUT	/engagements/18/baseline	\N	\N	200	172.19.0.8	\N	2026-08-04 06:27:07.082669+00
362	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 06:29:39.079222+00
363	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 07:05:56.251732+00
364	1	post	POST	/users	\N	\N	201	172.19.0.1	\N	2026-08-04 07:05:56.619382+00
365	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 07:06:23.442497+00
366	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 07:10:30.092222+00
367	1	post	POST	/engagements/18/members	\N	\N	201	172.19.0.1	\N	2026-08-04 07:10:30.489372+00
368	1	post	POST	/engagements/18/members	\N	\N	409	172.19.0.1	\N	2026-08-04 07:10:30.531312+00
369	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 07:11:01.10327+00
370	6	post	POST	/engagements/18/members	\N	\N	403	172.19.0.1	\N	2026-08-04 07:11:01.274258+00
371	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 07:11:31.98338+00
372	1	delete	DELETE	/engagements/18/members/6	\N	\N	204	172.19.0.1	\N	2026-08-04 07:11:32.26193+00
373	1	delete	DELETE	/engagements/18/members/1	\N	\N	409	172.19.0.1	\N	2026-08-04 07:11:32.313495+00
374	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 07:24:03.168258+00
375	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 07:24:03.416136+00
376	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 07:24:34.644509+00
377	1	put	PUT	/engagements/18/details	\N	\N	200	172.19.0.1	\N	2026-08-04 07:24:34.739661+00
378	1	put	PUT	/engagements/18/details	\N	\N	422	172.19.0.1	\N	2026-08-04 07:24:34.780555+00
379	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 07:25:05.30971+00
380	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 07:25:33.686364+00
381	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 07:27:35.057759+00
382	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 07:28:05.778061+00
383	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-04 07:40:19.232289+00
384	\N	post	POST	/api/auth/login	\N	\N	404	172.19.0.1	\N	2026-08-10 01:35:14.491107+00
385	\N	post	POST	/api/auth/login	\N	\N	404	172.19.0.1	\N	2026-08-10 01:35:21.289569+00
386	\N	post	POST	/auth/login	\N	\N	422	172.19.0.1	\N	2026-08-10 01:35:40.787516+00
387	\N	post	POST	/auth/login	\N	\N	422	172.19.0.1	\N	2026-08-10 01:35:53.022552+00
388	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 01:36:02.989718+00
389	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 01:36:15.3095+00
390	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 01:36:27.174033+00
391	\N	post	POST	/auth/login	\N	\N	401	172.19.0.1	\N	2026-08-10 01:36:27.43348+00
392	\N	post	POST	/auth/login	\N	\N	401	172.19.0.1	\N	2026-08-10 01:36:27.679185+00
393	\N	post	POST	/auth/login	\N	\N	401	172.19.0.1	\N	2026-08-10 01:36:27.917669+00
394	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 01:36:38.286586+00
395	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 01:36:56.425405+00
397	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 01:41:20.005568+00
400	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 01:41:52.302396+00
401	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 01:42:08.789651+00
402	\N	post	POST	/auth/login	\N	\N	200	172.19.0.8	\N	2026-08-10 01:44:09.538748+00
396	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 01:36:56.670042+00
398	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 01:41:32.222555+00
399	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 01:41:41.37739+00
403	1	put	PUT	/engagements/18/details	\N	\N	200	172.19.0.8	\N	2026-08-10 01:48:33.224492+00
404	1	post	POST	/engagements/18/members	\N	\N	201	172.19.0.8	\N	2026-08-10 01:48:51.08141+00
405	\N	post	POST	/auth/login	\N	\N	200	172.19.0.8	\N	2026-08-10 01:49:19.958009+00
406	\N	post	POST	/auth/login	\N	\N	200	172.19.0.8	\N	2026-08-10 01:50:01.304258+00
407	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 01:55:30.596697+00
408	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 02:18:09.035083+00
409	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 02:42:58.683667+00
410	1	post	POST	/engagements/18/findings/167/status	\N	\N	200	172.19.0.1	\N	2026-08-10 02:42:58.798365+00
411	1	post	POST	/engagements/18/findings/167/status	\N	\N	200	172.19.0.1	\N	2026-08-10 02:42:58.859292+00
412	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 02:43:19.793919+00
413	1	post	POST	/engagements/18/findings/167/status	\N	\N	200	172.19.0.1	\N	2026-08-10 02:43:19.861386+00
414	1	post	POST	/engagements/18/findings/167/status	\N	\N	200	172.19.0.1	\N	2026-08-10 02:43:19.917304+00
415	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 02:48:25.482949+00
416	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 02:48:25.735826+00
417	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.1	telusur basis pengetahuan q= cwe= hasil=10	2026-08-10 02:48:25.956728+00
418	1	read	GET	/knowledge/suggest	knowledge	165	200	172.19.0.1	saran basis pengetahuan untuk temuan 165, 2 hasil	2026-08-10 02:48:26.085529+00
419	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 02:50:21.859729+00
420	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.1	telusur basis pengetahuan q= cwe= hasil=10	2026-08-10 02:50:21.971137+00
421	1	post	POST	/engagements/18/findings/164/apply-knowledge/10	\N	\N	200	172.19.0.1	\N	2026-08-10 02:50:22.058495+00
422	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.1	telusur basis pengetahuan q= cwe= hasil=10	2026-08-10 02:50:22.161606+00
423	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 02:50:41.645022+00
424	2	post	POST	/engagements/18/findings/164/apply-knowledge/1	\N	\N	403	172.19.0.1	\N	2026-08-10 02:50:41.689859+00
425	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 02:51:21.804593+00
426	1	post	POST	/engagements/18/findings/164/apply-knowledge/5	\N	\N	200	172.19.0.1	\N	2026-08-10 02:51:21.86242+00
427	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.1	telusur basis pengetahuan q= cwe= hasil=10	2026-08-10 02:51:21.967211+00
428	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.8	telusur basis pengetahuan q= cwe= hasil=10	2026-08-10 02:57:21.312845+00
429	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 03:02:20.403974+00
430	1	put	PUT	/engagements/17/details	\N	\N	200	172.19.0.1	\N	2026-08-10 03:02:20.459975+00
431	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 03:02:44.456605+00
432	1	post	POST	/engagements/17/findings/152/status	\N	\N	200	172.19.0.1	\N	2026-08-10 03:02:44.794245+00
433	1	post	POST	/engagements/17/findings/152/status	\N	\N	200	172.19.0.1	\N	2026-08-10 03:02:44.842283+00
434	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 03:03:18.466284+00
435	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.1	telusur basis pengetahuan q= cwe= hasil=10	2026-08-10 03:03:18.766747+00
436	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 03:04:50.216529+00
437	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.1	telusur basis pengetahuan q= cwe= hasil=7	2026-08-10 03:04:50.311491+00
438	1	read	GET	/knowledge/suggest	knowledge	165	200	172.19.0.1	saran basis pengetahuan untuk temuan 165, 1 hasil	2026-08-10 03:04:50.374379+00
439	1	put	PUT	/engagements/17/details	\N	\N	200	172.19.0.1	\N	2026-08-10 03:04:50.435813+00
440	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.1	telusur basis pengetahuan q= cwe= hasil=10	2026-08-10 03:04:50.476766+00
441	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 03:06:13.068887+00
442	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 03:06:13.31515+00
443	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.8	telusur basis pengetahuan q= cwe= hasil=10	2026-08-10 03:20:12.960163+00
444	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.8	telusur basis pengetahuan q= cwe= hasil=10	2026-08-10 03:20:49.722165+00
445	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.8	telusur basis pengetahuan q=l cwe= hasil=7	2026-08-10 03:20:51.244722+00
446	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.8	telusur basis pengetahuan q=lo cwe= hasil=3	2026-08-10 03:20:51.416074+00
447	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.8	telusur basis pengetahuan q=log cwe= hasil=3	2026-08-10 03:20:51.573633+00
448	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.8	telusur basis pengetahuan q=log4 cwe= hasil=3	2026-08-10 03:20:53.322815+00
449	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.8	telusur basis pengetahuan q=log4j cwe= hasil=3	2026-08-10 03:20:53.447844+00
450	1	put	PUT	/engagements/17/details	\N	\N	200	172.19.0.8	\N	2026-08-10 03:21:49.076293+00
451	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.8	telusur basis pengetahuan q= cwe= hasil=7	2026-08-10 03:21:58.526144+00
452	1	put	PUT	/engagements/17/details	\N	\N	200	172.19.0.8	\N	2026-08-10 03:22:23.846458+00
453	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.8	telusur basis pengetahuan q= cwe= hasil=10	2026-08-10 03:22:27.665804+00
454	\N	post	POST	/auth/login	\N	\N	200	172.19.0.8	\N	2026-08-10 03:22:50.141728+00
455	\N	post	POST	/auth/login	\N	\N	200	172.19.0.8	\N	2026-08-10 03:23:14.936162+00
456	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 04:22:39.743302+00
457	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.1	telusur basis pengetahuan q= cwe= hasil=10	2026-08-10 04:22:39.90766+00
458	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 04:50:57.509598+00
459	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 04:51:03.311549+00
460	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 04:52:10.755729+00
461	1	post	POST	/engagements	\N	\N	201	172.19.0.1	\N	2026-08-10 04:52:10.849395+00
462	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 06:22:33.790979+00
463	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 06:23:01.107042+00
464	1	post	POST	/engagements/19/generate-narratives	\N	\N	200	172.19.0.1	\N	2026-08-10 06:23:01.582111+00
465	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 06:23:25.520759+00
466	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 06:24:05.444817+00
467	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 06:24:32.153123+00
468	1	post	POST	/engagements/19/findings/168/status	\N	\N	200	172.19.0.1	\N	2026-08-10 06:24:32.30724+00
469	1	post	POST	/engagements/19/findings/168/status	\N	\N	200	172.19.0.1	\N	2026-08-10 06:24:32.359326+00
470	1	post	POST	/engagements/19/findings/169/status	\N	\N	200	172.19.0.1	\N	2026-08-10 06:24:32.412116+00
471	1	post	POST	/engagements/19/findings/169/status	\N	\N	200	172.19.0.1	\N	2026-08-10 06:24:32.454991+00
472	1	post	POST	/engagements/19/findings/170/status	\N	\N	200	172.19.0.1	\N	2026-08-10 06:24:32.507089+00
473	1	post	POST	/engagements/19/findings/170/status	\N	\N	200	172.19.0.1	\N	2026-08-10 06:24:32.550433+00
474	1	post	POST	/engagements/19/findings/171/status	\N	\N	200	172.19.0.1	\N	2026-08-10 06:24:32.597996+00
475	1	post	POST	/engagements/19/findings/171/status	\N	\N	200	172.19.0.1	\N	2026-08-10 06:24:32.637881+00
476	1	post	POST	/engagements/19/findings/172/status	\N	\N	200	172.19.0.1	\N	2026-08-10 06:24:32.68204+00
477	1	post	POST	/engagements/19/findings/172/status	\N	\N	200	172.19.0.1	\N	2026-08-10 06:24:32.726263+00
479	1	post	POST	/engagements/19/exec-summary	\N	\N	200	172.19.0.1	\N	2026-08-10 06:24:58.364341+00
480	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 06:25:32.807875+00
483	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.1	telusur basis pengetahuan q= cwe= hasil=13	2026-08-10 06:44:37.077735+00
484	1	read	GET	/knowledge/suggest	knowledge	170	200	172.19.0.1	saran basis pengetahuan untuk temuan 170, 2 hasil	2026-08-10 06:44:38.923222+00
478	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 06:24:58.298876+00
481	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 06:26:06.273824+00
482	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 06:44:36.836573+00
485	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 06:45:08.925668+00
486	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 06:49:22.627167+00
487	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 07:01:31.342077+00
488	1	read	GET	/knowledge/suggest	knowledge	170	200	172.19.0.8	saran basis pengetahuan untuk temuan 170, 2 hasil	2026-08-10 07:04:40.852449+00
489	1	post	POST	/engagements/19/findings/170/apply-knowledge/6	\N	\N	200	172.19.0.8	\N	2026-08-10 07:05:33.013738+00
490	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 07:07:04.65056+00
491	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 07:12:47.719949+00
492	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.1	telusur basis pengetahuan q= cwe= hasil=13	2026-08-10 07:12:47.872589+00
493	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 07:23:22.531618+00
494	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.1	telusur basis pengetahuan q= cwe= hasil=13	2026-08-10 07:23:22.980019+00
495	1	read	GET	/knowledge/suggest	knowledge	168	200	172.19.0.1	saran basis pengetahuan untuk temuan 168, 1 hasil	2026-08-10 07:23:24.548401+00
496	1	delete	DELETE	/engagements/19	\N	\N	400	172.19.0.1	\N	2026-08-10 07:23:24.643819+00
497	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 07:24:59.267893+00
498	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.1	telusur basis pengetahuan q= cwe= hasil=13	2026-08-10 07:24:59.770079+00
499	1	read	GET	/knowledge/suggest	knowledge	168	200	172.19.0.1	saran basis pengetahuan untuk temuan 168, 1 hasil	2026-08-10 07:25:00.516773+00
500	1	delete	DELETE	/engagements/19	\N	\N	400	172.19.0.1	\N	2026-08-10 07:25:02.230283+00
501	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 07:25:37.963395+00
502	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.1	telusur basis pengetahuan q= cwe= hasil=13	2026-08-10 07:25:38.442793+00
503	1	read	GET	/knowledge/suggest	knowledge	168	200	172.19.0.1	saran basis pengetahuan untuk temuan 168, 1 hasil	2026-08-10 07:25:39.184611+00
504	1	delete	DELETE	/engagements/19	\N	\N	400	172.19.0.1	\N	2026-08-10 07:25:41.086677+00
505	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 07:32:04.173507+00
506	1	post	POST	/engagements	\N	\N	201	172.19.0.1	\N	2026-08-10 07:32:04.285122+00
507	1	post	POST	/engagements/20/uploads	\N	\N	201	172.19.0.1	\N	2026-08-10 07:32:04.549842+00
508	1	delete	DELETE	/engagements/20	\N	\N	400	172.19.0.1	\N	2026-08-10 07:32:11.771174+00
509	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 07:32:12.027542+00
510	3	delete	DELETE	/engagements/20	\N	\N	403	172.19.0.1	\N	2026-08-10 07:32:12.085784+00
511	1	delete	DELETE	/engagements/20	\N	\N	200	172.19.0.1	\N	2026-08-10 07:32:12.217316+00
512	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 07:32:49.880212+00
513	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 07:36:16.962675+00
514	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.1	telusur basis pengetahuan q= cwe= hasil=13	2026-08-10 07:36:17.359728+00
515	1	read	GET	/knowledge/suggest	knowledge	168	200	172.19.0.1	saran basis pengetahuan untuk temuan 168, 1 hasil	2026-08-10 07:36:18.048992+00
516	1	delete	DELETE	/engagements/19	\N	\N	400	172.19.0.1	\N	2026-08-10 07:36:19.966978+00
517	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 07:51:46.990033+00
518	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.1	telusur basis pengetahuan q= cwe= hasil=13	2026-08-10 07:51:47.364887+00
519	1	read	GET	/knowledge/suggest	knowledge	168	200	172.19.0.1	saran basis pengetahuan untuk temuan 168, 1 hasil	2026-08-10 07:51:48.065594+00
520	1	delete	DELETE	/engagements/19	\N	\N	400	172.19.0.1	\N	2026-08-10 07:51:49.860186+00
521	\N	post	POST	/auth/login	\N	\N	200	172.19.0.1	\N	2026-08-10 07:53:17.614938+00
522	1	read	GET	/knowledge	knowledge	\N	200	172.19.0.1	telusur basis pengetahuan q= cwe= hasil=13	2026-08-10 07:53:18.023737+00
523	1	read	GET	/knowledge/suggest	knowledge	168	200	172.19.0.1	saran basis pengetahuan untuk temuan 168, 1 hasil	2026-08-10 07:53:18.764859+00
524	1	delete	DELETE	/engagements/19	\N	\N	400	172.19.0.1	\N	2026-08-10 07:53:20.60493+00
\.


--
-- Data for Name: engagement_members; Type: TABLE DATA; Schema: public; Owner: auditforge
--

COPY public.engagement_members (id, engagement_id, user_id, role_in_team, added_by, created_at) FROM stdin;
16	18	1	lead	\N	2026-08-04 07:47:26.111367+00
18	17	1	lead	\N	2026-08-04 07:47:26.111367+00
19	18	3	member	1	2026-08-10 01:48:51.07065+00
20	19	1	lead	1	2026-08-10 04:52:10.838384+00
\.


--
-- Data for Name: engagements; Type: TABLE DATA; Schema: public; Owner: auditforge
--

COPY public.engagements (id, name, client_name, description, status, created_by, created_at, exec_summary_generated, exec_summary_model, exec_summary_prompt_version, exec_summary, baseline_hours, baseline_note, exec_summary_finding_count, scope, period_start, period_end, kb_shareable) FROM stdin;
19	Audit Portal Pelanggan 2026	PT Contoh	\N	completed	1	2026-08-10 04:52:10.82338+00	t	google/gemma-4-26b-a4b-it:free	summary-v1	{"overview": "Audit 'Uji Alur Penuh' pada PT Contoh mengidentifikasi total 5 temuan keamanan dengan cakupan yang mencakup berbagai kategori OWASP. Postur keamanan saat ini menunjukkan adanya kerentanan kritis yang memerlukan perhatian segera guna memitigasi risiko eksploitasi langsung.", "key_risks": "Risiko paling kritis adalah kerentanan Remote Code Execution pada Apache Log4j2 (Log4Shell) yang memungkinkan penyerang mengambil alih kontrol sistem secara penuh. Selain itu, terdapat risiko Cross-Site Scripting (XSS) yang dapat mengancam integritas sesi pengguna pada aplikasi.", "recommendations": "Prioritas utama adalah melakukan patching segera pada komponen Log4j2 untuk menutup celah RCE. Selanjutnya, disarankan untuk memperbaiki kerentanan Cross-Site Scripting dan memperkuat mekanisme kontrol akses serta integritas data sesuai standar OWASP.", "posture": "critical"}	\N	\N	5	Portal pelanggan: halaman publik, alur masuk, dan API pencarian	2026-08-05	2026-08-10	t
17	Audit Infrastruktur Internal — Fase 1	PT Suryasoft Konsultama	\N	in_progress	1	2026-08-03 01:44:52.318216+00	t	google/gemma-4-26b-a4b-it:free	summary-v1	{"overview": "Audit ini mencakup pengujian penetrasi (Uji UI Part 1) terhadap infrastruktur internal klien. Hasil pemeriksaan mengidentifikasi total 4 temuan, dengan 1 temuan berkategori risiko tinggi (high) dan 3 temuan informasional.", "key_risks": "Risiko utama yang teridentifikasi adalah kerentanan OpenSSL Heartbleed pada [P1 \\u00b7 high \\u00b7 CVSS 7.5] yang memungkinkan eksploitasi memori. Temuan ini merupakan prioritas tertinggi karena memiliki CVE publik dan dapat berdampak langsung pada kerahasiaan data.", "recommendations": "Prioritas utama adalah segera melakukan penambalan (patching) pada layanan terkait untuk mengatasi kerentanan Heartbleed. Setelah itu, lakukan peninjauan terhadap konfigurasi port terbuka dan standar enkripsi yang tersedia untuk meningkatkan postur keamanan secara keseluruhan.", "posture": "critical"}	6	Estimasi penyusunan manual (verifikasi Modul 1)	4	Pemindaian host internal: layanan terbuka, konfigurasi TLS, dan header keamanan	2026-07-20	2026-07-31	t
18	Audit Aplikasi Web Internal 2026	PT Contoh	\N	completed	1	2026-08-04 06:08:59.885462+00	t	google/gemma-4-26b-a4b-it:free	summary-v1	{"overview": "Audit uji coba internal pada PT Contoh mengidentifikasi total 5 temuan keamanan dengan cakupan yang mencakup berbagai kategori OWASP. Postur keamanan saat ini menunjukkan adanya kerentanan kritis yang memerlukan perhatian segera untuk memitigasi risiko eksploitasi.", "key_risks": "Risiko utama terletak pada kerentanan Log4Shell (Apache Log4j2) yang memiliki skor CVSS 10.0, yang memungkinkan eksekusi kode jarak jauh secara penuh. Selain itu, terdapat risiko terkait kendali akses dan kegagalan kriptografi yang dapat membahayakan integritas data serta integritas perangkat lunak.", "recommendations": "Prioritas utama adalah melakukan penambalan (patching) segera terhadap kerentanan Log4j2 untuk menutup celah eksekusi kode. Selanjutnya, perusahaan harus memprioritaskan perbaikan pada kerentanan Cross Site Scripting dan memperkuat mekanisme kontrol akses serta integritas data secara menyeluruh.", "posture": "critical"}	6	estimasi kasar, 3 naratif disunting penuh	5	Aplikasi web internal + API (autentikasi, modul laporan, endpoint publik)	2026-08-01	2026-08-10	t
\.


--
-- Data for Name: finding_attachments; Type: TABLE DATA; Schema: public; Owner: auditforge
--

COPY public.finding_attachments (id, finding_id, filename, storage_key, content_type, size, uploaded_by, created_at) FROM stdin;
\.


--
-- Data for Name: finding_revisions; Type: TABLE DATA; Schema: public; Owner: auditforge
--

COPY public.finding_revisions (id, finding_id, action, status, narrative, note, author_id, created_at) FROM stdin;
81	169	submit	in_review	null	\N	1	2026-08-10 06:24:32.407673+00
82	169	approve	approved	null	\N	1	2026-08-10 06:24:32.448196+00
83	170	submit	in_review	null	\N	1	2026-08-10 06:24:32.503047+00
36	155	submit	in_review	null	\N	1	2026-08-03 01:46:08.941687+00
37	152	ai_draft	draft	{"description": "Ditemukan port 22/tcp yang terbuka pada 192.0.2.10 yang menjalankan layanan OpenSSH versi 7.4. Port ini merupakan layanan standar untuk protokol Secure Shell (SSH) yang digunakan untuk akses administratif jarak jauh.", "impact": "Meskipun bersifat informasi, port yang terbuka meningkatkan permukaan serangan bagi aktor ancaman untuk mencoba melakukan autentikasi paksa atau eksploitasi terhadap layanan tersebut.", "recommendation": "Pastikan layanan SSH hanya dapat diakses dari jaringan internal yang terpercaya dan pastikan versi OpenSSH telah diperbarui ke versi terbaru yang mendukung patch keamanan terkini."}	AI · google/gemma-4-26b-a4b-it:free · narrative-v1	\N	2026-08-03 01:46:25.500373+00
38	155	ai_draft	in_review	{"description": "Sistem teridentifikasi rentan terhadap kerentanan Heartbleed (CVE-2014-0160) pada layanan SSL/TLS di 192.0.2.10:443/tcp. Kerentanan ini terjadi akibat kesalahan implementasi pada ekstensi Heartbeat dalam protokol TLS yang memungkinkan pembacaan memori server secara tidak sah.", "impact": "Eksploitasi kerentanan ini dapat menyebabkan kebocoran informasi sensitif dari memori server, termasuk kredensial pengguna, kunci enkripsi, maupun data rahasia lainnya, yang dapat digunakan untuk mengambil alih sesi komunikasi.", "recommendation": "Segera lakukan pembaruan (patching) pada pustaka OpenSSL ke versi yang telah memperbaiki kerentanan ini. Selain itu, disarankan untuk melakukan rotasi sertifikat SSL/TLS dan kredensial yang berisiko telah terkompromi."}	AI · google/gemma-4-26b-a4b-it:free · narrative-v1	\N	2026-08-03 01:46:30.029751+00
39	154	ai_draft	draft	{"description": "Hasil pemindaian menunjukkan bahwa layanan pada 192.0.2.10 mendukung protokol TLSv1.0. Protokol ini menggunakan suite kriptografi yang lemah dan dianggap sudah usang.", "impact": "Penggunaan protokol TLS yang usang memungkinkan penyerang melakukan serangan downgrade atau eksploitasi pada enkripsi yang lemah. Hal ini dapat mengakibatkan kebocoran data sensitif selama proses transmisi.", "recommendation": "Nonaktifkan dukungan untuk TLSv1.0 dan TLSv1.1 pada layanan 192.0.2.10. Implementasikan penggunaan TLSv1.2 atau versi yang lebih baru untuk memastikan standar keamanan yang memadai."}	AI · google/gemma-4-26b-a4b-it:free · narrative-v1	\N	2026-08-03 01:46:34.432712+00
40	153	ai_draft	draft	{"description": "Terdeteksi port 443/tcp terbuka pada target 192.0.2.10 yang menjalankan layanan HTTPS melalui web server nginx versi 1.14.0. Port ini merupakan port standar untuk lalu lintas HTTPS yang terenkripsi.", "impact": "Port yang terbuka dapat menjadi titik masuk potensial untuk serangan terhadap layanan web jika terdapat kerentanan pada konfigurasi atau versi layanan yang digunakan. Risiko ini umumnya bersifat informasional dalam konteks pemindaian permukaan serangan.", "recommendation": "Pastikan layanan HTTPS dikonfigurasi dengan standar keamanan terkini dan pastikan versi nginx yang digunakan telah diperbarui untuk menghindari kerentanan yang diketahui pada versi lama."}	AI · google/gemma-4-26b-a4b-it:free · narrative-v1	\N	2026-08-03 01:46:49.468853+00
41	157	ai_draft	draft	{"description": "Halaman web yang diakses melalui protokol HTTPS pada https://example.com/page memuat sumber daya (seperti skrip, gambar, atau gaya) menggunakan protokol HTTP yang tidak aman. Hal ini menyebabkan ketidakkonsistenan pada koneksi terenkripsi yang seharusnya diterapkan secara menyeluruh pada halaman tersebut.", "impact": "Eksploitasi terhadap mixed content dapat memungkinkan penyerang melakukan serangan Man-in-the-Middle (MitM) untuk menyuntikkan konten berbahaya atau melakukan sniffing terhadap data yang dikirimkan melalui koneksi HTTP yang tidak terenkripsi tersebut.", "recommendation": "Perbarui semua referensi sumber daya dalam kode HTML agar menggunakan protokol HTTPS secara konsisten. Implementasikan kebijakan Content Security Policy (CSP) dengan direktif 'upgrade-insecure-requests' untuk memaksa browser memuat semua sumber daya melalui HTTPS."}	AI · google/gemma-4-26b-a4b-it:free · narrative-v1	\N	2026-08-03 01:53:29.537141+00
42	158	ai_draft	draft	{"description": "Aplikasi yang berjalan pada https://example.com/api/login menggunakan pustaka Apache Log4j2 yang rentan terhadap kerentanan remote code execution (RCE) melalui fitur JNDI lookup. Penyerang dapat menyisipkan string manipulasi pada parameter input yang akan dieksekusi oleh pustaka tersebut, memungkinkan eksekusi kode arbitrer pada server.", "impact": "Eksploitasi kerentanan ini memungkinkan penyerang untuk mengambil kendali penuh atas server, mencuri data sensitif, atau melakukan pergerakan lateral di dalam jaringan internal. Hal ini menimbulkan risiko keamanan tingkat kritis terhadap integritas dan kerahasiaan sistem.", "recommendation": "Segera perbarui pustaka Apache Log4j2 ke versi terbaru yang telah menambal kerentanan ini (minimal versi 2.17.1 untuk Java 8). Jika pembaruan tidak dapat dilakukan segera, nonaktifkan fitur lookup melalui konfigurasi sistem atau gunakan mitigasi berbasis WAF."}	AI · google/gemma-4-26b-a4b-it:free · narrative-v1	\N	2026-08-03 01:53:34.515291+00
84	170	approve	approved	null	\N	1	2026-08-10 06:24:32.545818+00
43	156	ai_draft	draft	{"description": "Sistem terdeteksi mendukung berbagai versi protokol TLS saat melakukan komunikasi pada target example.com:443. Deteksi versi protokol ini memungkinkan penyerang untuk mengetahui konfigurasi enkripsi yang digunakan oleh server.", "impact": "Informasi mengenai versi TLS yang didukung dapat membantu penyerang dalam menentukan kerentanan spesifik pada protokol tersebut untuk melakukan serangan downgrade atau penyadapan komunikasi.", "recommendation": "Lakukan audit terhadap konfigurasi SSL/TLS pada server dan pastikan hanya versi TLS yang aman (seperti TLS 1.2 atau TLS 1.3) yang diaktifkan, serta menonaktifkan versi protokol yang sudah usang."}	AI · google/gemma-4-26b-a4b-it:free · narrative-v1	\N	2026-08-03 01:53:37.193959+00
44	158	submit	in_review	null	\N	1	2026-08-04 02:17:01.380659+00
45	158	approve	approved	null	\N	1	2026-08-04 02:17:02.740823+00
46	155	approve	approved	null	\N	1	2026-08-04 02:17:17.235017+00
47	157	submit	in_review	null	\N	1	2026-08-04 02:17:29.171319+00
48	157	approve	approved	null	\N	1	2026-08-04 02:17:30.434521+00
49	158	edit	approved	{"description": "Aplikasi yang berjalan pada https://example.com/api/login menggunakan pustaka Apache Log4j2 yang rentan terhadap kerentanan remote code execution (RCE) melalui fitur JNDI lookup. Penyerang dapat memasukkan string manipulasi pada parameter input yang akan dieksekusi oleh pustaka tersebut, memungkinkan eksekusi kode arbitrer pada server.", "impact": "Eksploitasi kerentanan ini memungkinkan penyerang untuk mengambil kontrol penuh atas server, mencuri data sensitif, atau melakukan pergerakan lateral di dalam jaringan internal. Hal ini menimbulkan risiko keamanan tingkat kritis terhadap integritas dan kerahasiaan sistem.", "recommendation": "Segera perbarui pustaka Apache Log4j2 ke versi terbaru yang telah menambal kerentanan ini (minimal versi 2.17.1 untuk Java 8). Jika pembaruan tidak dapat dilakukan segera, nonaktifkan fitur lookup melalui konfigurasi sistem atau gunakan mitigasi berbasis WAF."}	\N	1	2026-08-04 03:06:48.839249+00
50	163	ai_draft	draft	{"description": "Sistem terdeteksi mendukung protokol Transport Layer Security (TLS) yang dapat diidentifikasi melalui pemeriksaan pada target example.com:443. Informasi versi TLS yang tersedia dapat memberikan petunjuk mengenai konfigurasi keamanan server kepada pihak luar.", "impact": "Meskipun hanya bersifat informatif, pengungkapan versi protokol dapat membantu penyerang dalam memetakan permukaan serangan dan menentukan potensi kerentanan pada versi TLS yang digunakan.", "recommendation": "Pastikan hanya versi TLS yang kuat dan aman (seperti TLS 1.2 atau 1.3) yang diaktifkan, serta pertimbangkan untuk menyembunyikan informasi detail versi protokol pada respons server jika memungkinkan."}	AI · google/gemma-4-26b-a4b-it:free · narrative-v1	\N	2026-08-04 06:11:47.582148+00
51	164	ai_draft	draft	{"description": "Halaman web yang diakses melalui protokol HTTPS pada https://example.com/page memuat sumber daya melalui protokol HTTP yang tidak terenkripsi. Kondisi mixed content ini menyebabkan komunikasi antara klien dan server untuk sumber daya tersebut tidak terlindungi oleh enkripsi SSL/TLS.", "impact": "Penyerang dapat melakukan serangan Man-in-the-Middle (MitM) untuk mencegat atau memodifikasi data yang dikirimkan melalui sumber daya HTTP tersebut. Hal ini dapat menyebabkan kebocoran informasi sensitif atau manipulasi konten pada halaman yang seharusnya aman.", "recommendation": "Perbarui seluruh URL sumber daya (seperti skrip, gambar, atau stylesheet) agar menggunakan protokol HTTPS. Implementasikan kebijakan Content Security Policy (CSP) dengan direktif 'upgrade-insecure-requests' untuk memaksa pemuatan sumber daya melalui HTTPS."}	AI · google/gemma-4-26b-a4b-it:free · narrative-v1	\N	2026-08-04 06:11:49.022215+00
52	167	ai_draft	draft	{"description": "Ditemukan kerentanan Cross-Site Scripting (Reflected) pada parameter 'q' di endpoint http://example.com/search. Hal ini terjadi karena aplikasi tidak melakukan sanitasi atau encoding yang memadai terhadap input pengguna sebelum menampilkannya kembali ke halaman web.", "impact": "Penyerang dapat menyisipkan skrip berbahaya yang dieksekusi di browser korban, yang dapat mengakibatkan pencurian sesi (session hijacking), manipulasi konten halaman, atau pengalihan pengguna ke situs berbahaya.", "recommendation": "Implementasikan sanitasi input yang ketat dan gunakan context-aware output encoding pada semua data yang berasal dari parameter URL sebelum ditampilkan di browser."}	AI · google/gemma-4-26b-a4b-it:free · narrative-v1	\N	2026-08-04 06:11:55.223544+00
53	165	ai_draft	draft	{"description": "Terdeteksi kerentanan Remote Code Execution (RCE) pada komponen Apache Log4j2 di endpoint https://example.com/api/login akibat mekanisme lookup JNDI yang tidak aman. Penyerang dapat mengeksploitasi kerentanan ini dengan mengirimkan string khusus dalam input yang akan dieksekusi oleh pustaka log tersebut. Celah ini merupakan implementasi dari CWE-502 terkait deserialisasi data yang tidak aman.", "impact": "Penyerang dapat mengeksekusi perintah arbitrer pada server target, yang dapat menyebabkan pengambilalihan kendali penuh atas sistem, pencurian data sensitif, atau eskalasi hak akses. Tingkat keparahan dikategorikan sebagai Critical dengan skor CVSS 10.0.", "recommendation": "Segera lakukan pembaruan (upgrade) pada pustaka Apache Log4j2 ke versi terbaru yang telah menambal celah keamanan ini. Selain itu, pertimbangkan untuk menerapkan aturan WAF (Web Application Firewall) untuk memfilter upaya eksploitasi berbasis JNDI lookup."}	AI · google/gemma-4-26b-a4b-it:free · narrative-v1	\N	2026-08-04 06:11:57.946092+00
54	166	ai_draft	draft	{"description": "Formulir pengiriman HTML pada endpoint http://example.com/login tidak menyertakan token Anti-CSRF. Hal ini terjadi karena tidak adanya mekanisme validasi unik untuk memverifikasi bahwa permintaan formulir berasal dari pengguna yang sah melalui sesi yang valid.", "impact": "Tanpa perlindungan Anti-CSRF, penyerang dapat melakukan serangan Cross-Site Request Forgery (CSRF) untuk memanipulasi permintaan dari pengguna yang terautentikasi. Hal ini dapat menyebabkan tindakan yang tidak sah, seperti perubahan kredensial atau aktivasi akun tanpa sepengetahuan pengguna.", "recommendation": "Implementasikan token Anti-CSRF yang unik dan sulit ditebak untuk setiap sesi pengguna dalam setiap formulir HTML. Selain itu, gunakan validasi berbasis SameSite cookie attributes untuk memberikan lapisan perlindungan tambahan."}	AI · google/gemma-4-26b-a4b-it:free · narrative-v1	\N	2026-08-04 06:12:02.876647+00
55	165	submit	in_review	null	\N	1	2026-08-04 06:12:58.976164+00
56	165	approve	approved	null	\N	1	2026-08-04 06:12:59.925345+00
57	167	submit	in_review	null	\N	1	2026-08-04 06:13:04.110651+00
58	167	approve	approved	null	\N	1	2026-08-04 06:13:05.056272+00
59	164	submit	in_review	null	\N	1	2026-08-04 06:13:08.372003+00
60	164	approve	approved	null	\N	1	2026-08-04 06:13:10.990187+00
61	163	submit	in_review	null	\N	1	2026-08-04 06:13:14.508823+00
62	163	approve	approved	null	\N	1	2026-08-04 06:13:16.359838+00
63	166	submit	in_review	null	\N	1	2026-08-04 06:13:20.262309+00
64	166	approve	approved	null	\N	1	2026-08-04 06:13:21.308623+00
85	171	submit	in_review	null	\N	1	2026-08-10 06:24:32.593788+00
86	171	approve	approved	null	\N	1	2026-08-10 06:24:32.633473+00
87	172	submit	in_review	null	\N	1	2026-08-10 06:24:32.677714+00
88	172	approve	approved	null	\N	1	2026-08-10 06:24:32.721788+00
65	165	edit	approved	{"description": "Terdeteksi kerentanan Remote Code Execution (RCE) pada komponen Apache Log4j2 di endpoint https://example.com/api/login akibat mekanisme lookup JNDI yang tidak aman. Penyerang dapat mengeksploitasi kerentanan ini dengan mengirim string khusus dalam input yang akan dieksekusi oleh pustaka log tersebut. Celah ini merupakan implementasi dari CWE-502 terkait deserialisasi data yang tidak aman.", "impact": "Penyerang dapat menjalankan perintah arbitrer pada server target, yang dapat menyebabkan pengambilalihan kendali penuh atas sistem, pencurian data sensitif, atau eskalasi hak akses. Tingkat keparahan dikategorikan sebagai Critical dengan skor CVSS 10.0.", "recommendation": "Segera lakukan pembaruan (upgrade) pada pustaka Apache Log4j2 ke versi terbaru yang telah menutup celah keamanan ini. Selain itu, pertimbangkan untuk menerapkan aturan WAF (Web Application Firewall) untuk memfilter upaya eksploitasi berbasis JNDI lookup."}	\N	1	2026-08-04 06:26:13.260004+00
66	167	submit	in_review	null	\N	1	2026-08-10 02:42:58.787665+00
67	167	approve	approved	null	\N	1	2026-08-10 02:42:58.850354+00
68	167	submit	in_review	null	\N	1	2026-08-10 02:43:19.851222+00
69	167	approve	approved	null	\N	1	2026-08-10 02:43:19.909133+00
70	164	edit	approved	{"description": "Formulir pengiriman HTML pada endpoint http://example.com/login tidak menyertakan token Anti-CSRF. Hal ini terjadi karena tidak adanya mekanisme validasi unik untuk memverifikasi bahwa permintaan formulir berasal dari pengguna yang sah melalui sesi yang valid.", "impact": "Tanpa perlindungan Anti-CSRF, penyerang dapat melakukan serangan Cross-Site Request Forgery (CSRF) untuk memanipulasi permintaan dari pengguna yang terautentikasi. Hal ini dapat menyebabkan tindakan yang tidak sah, seperti perubahan kredensial atau aktivasi akun tanpa sepengetahuan pengguna.", "recommendation": "Implementasikan token Anti-CSRF yang unik dan sulit ditebak untuk setiap sesi pengguna dalam setiap formulir HTML. Selain itu, gunakan validasi berbasis SameSite cookie attributes untuk memberikan lapisan perlindungan tambahan."}	Naratif diambil dari Basis Pengetahuan (entri #10).	1	2026-08-10 02:50:22.048687+00
71	164	edit	approved	{"description": "Halaman web yang diakses melalui protokol HTTPS pada https://example.com/page memuat sumber daya (seperti skrip, gambar, atau gaya) menggunakan protokol HTTP yang tidak aman. Hal ini menyebabkan ketidakkonsistenan pada koneksi terenkripsi yang seharusnya diterapkan secara menyeluruh pada halaman tersebut.", "impact": "Eksploitasi terhadap mixed content dapat memungkinkan penyerang melakukan serangan Man-in-the-Middle (MitM) untuk menyuntikkan konten berbahaya atau melakukan sniffing terhadap data yang dikirimkan melalui koneksi HTTP yang tidak terenkripsi tersebut.", "recommendation": "Perbarui semua referensi sumber daya dalam kode HTML agar menggunakan protokol HTTPS secara konsisten. Implementasikan kebijakan Content Security Policy (CSP) dengan direktif 'upgrade-insecure-requests' untuk memaksa browser memuat semua sumber daya melalui HTTPS."}	Naratif diambil dari Basis Pengetahuan (entri #5).	1	2026-08-10 02:51:21.853496+00
72	152	submit	in_review	null	\N	1	2026-08-10 03:02:44.787529+00
73	152	approve	approved	null	\N	1	2026-08-10 03:02:44.836693+00
74	168	ai_draft	draft	{"description": "Server pada target example.com:443 terdeteksi mengizinkan penggunaan protokol TLS untuk enkripsi komunikasi. Deteksi versi TLS ini memberikan informasi mengenai protokol yang didukung oleh server kepada pihak luar.", "impact": "Informasi mengenai versi TLS yang didukung dapat membantu penyerang dalam memetakan profil keamanan server dan menentukan potensi kerentanan pada protokol yang digunakan.", "recommendation": "Pastikan server dikonfigurasi untuk hanya mendukung versi TLS yang aman (misalnya TLS 1.2 atau TLS 1.3) dan menonaktifkan versi TLS yang sudah usang."}	AI · google/gemma-4-26b-a4b-it:free · narrative-v1	\N	2026-08-10 06:23:07.515521+00
75	170	ai_draft	draft	{"description": "Ditemukan kerentanan Remote Code Execution (RCE) pada komponen Apache Log4j2 yang terletak di endpoint https://example.com/api/login. Kerentanan ini disebabkan oleh fitur lookup JNDI yang tidak aman, yang memungkinkan penyerang mengeksekusi kode arbitrer melalui manipulasi input yang kemudian diproses oleh library Log4j2.", "impact": "Penyerang dapat mengeksekusi kode secara jarak jauh pada server, yang dapat mengakibatkan pengambilalihan kendali sistem secara penuh, pencurian data sensitif, atau eskalasi hak akses. Kerentanan ini memiliki tingkat keparahan critical dengan skor CVSS 10.0.", "recommendation": "Segera lakukan pembaruan (update) Apache Log4j2 ke versi terbaru yang telah menambal celah keamanan ini (minimal versi 2.17.1 untuk Java 8). Jika pembaruan tidak memungkinkan, pertimbangkan untuk menonaktifkan konfigurasi lookup JNDI atau menerapkan filter pada level WAF."}	AI · google/gemma-4-26b-a4b-it:free · narrative-v1	\N	2026-08-10 06:23:11.743986+00
76	171	ai_draft	draft	{"description": "Formulir pengiriman HTML pada endpoint http://example.com/login tidak menyertakan token Anti-CSRF. Hal ini menyebabkan mekanisme autentikasi tidak memiliki proteksi terhadap serangan Cross-Site Request Forgery (CSRF).", "impact": "Penyerang dapat memaksa pengguna yang terautentikasi untuk melakukan tindakan yang tidak diinginkan tanpa sepengetahuan mereka. Dalam konteks ini, risiko mencakup manipulasi sesi atau tindakan akun lainnya melalui permintaan HTTP yang terfabrikasi.", "recommendation": "Implementasikan token CSRF yang unik dan sulit ditebak untuk setiap sesi pengguna dalam setiap formulir yang bersifat mengubah status (state-changing). Pastikan token tersebut divalidasi secara ketat pada sisi server saat memproses permintaan POST."}	AI · google/gemma-4-26b-a4b-it:free · narrative-v1	\N	2026-08-10 06:23:14.335282+00
77	169	ai_draft	draft	{"description": "Halaman web yang diakses melalui protokol HTTPS pada target https://example.com/page memuat sumber daya (seperti skrip, gambar, atau gaya) menggunakan protokol HTTP biasa. Kondisi ini menyebabkan konten tersebut dianggap sebagai 'Mixed Content' karena tidak memiliki enkripsi yang sama dengan halaman utama.", "impact": "Penyerang dapat melakukan serangan Man-in-the-Middle (MitM) untuk menyisipkan konten berbahaya atau memodifikasi sumber daya HTTP tersebut guna memanipulasi tampilan atau perilaku halaman. Hal ini dapat mengompromikan integritas data dan menurunkan kepercayaan pengguna terhadap keamanan situs.", "recommendation": "Perbarui semua referensi URL sumber daya dari protokol HTTP menjadi HTTPS. Implementasikan kebijakan 'Content Security Policy' (CSP) dengan direktif 'upgrade-insecure-requests' untuk secara otomatis memaksa permintaan ke versi HTTPS."}	AI · google/gemma-4-26b-a4b-it:free · narrative-v1	\N	2026-08-10 06:23:26.496527+00
78	172	ai_draft	draft	{"description": "Ditemukan kerentanan Cross-Site Scripting (XSS) Reflected pada parameter 'q' di URL http://example.com/search?q=test. Hal ini terjadi karena aplikasi tidak melakukan validasi atau sanitasi yang memadai terhadap input pengguna sebelum menampilkannya kembali pada halaman hasil pencarian.", "impact": "Penyerang dapat mengeksploitasi kerentanan ini untuk menjalankan skrip berbahaya di sisi klien korban, yang dapat mengakibatkan pencurian sesi (session hijacking), manipulasi konten halaman, atau pengalihan pengguna ke situs berbahaya.", "recommendation": "Terapkan sanitasi input yang ketat dan gunakan mekanisme output encoding (seperti HTML Entity Encoding) pada seluruh data yang berasal dari parameter URL sebelum ditampilkan pada browser."}	AI · google/gemma-4-26b-a4b-it:free · narrative-v1	\N	2026-08-10 06:23:32.255961+00
79	168	submit	in_review	null	\N	1	2026-08-10 06:24:32.294178+00
80	168	approve	approved	null	\N	1	2026-08-10 06:24:32.349808+00
89	170	edit	approved	{"description": "Aplikasi yang berjalan pada https://example.com/api/login menggunakan pustaka Apache Log4j2 yang rentan terhadap kerentanan remote code execution (RCE) melalui fitur JNDI lookup. Penyerang dapat memasukkan string manipulasi pada parameter input yang akan dieksekusi oleh pustaka tersebut, memungkinkan eksekusi kode arbitrer pada server.", "impact": "Eksploitasi kerentanan ini memungkinkan penyerang untuk mengambil kontrol penuh atas server, mencuri data sensitif, atau melakukan pergerakan lateral di dalam jaringan internal. Hal ini menimbulkan risiko keamanan tingkat kritis terhadap integritas dan kerahasiaan sistem.", "recommendation": "Segera perbarui pustaka Apache Log4j2 ke versi terbaru yang telah menambal kerentanan ini (minimal versi 2.17.1 untuk Java 8). Jika pembaruan tidak dapat dilakukan segera, nonaktifkan fitur lookup melalui konfigurasi sistem atau gunakan mitigasi berbasis WAF."}	Naratif diambil dari Basis Pengetahuan (entri #6).	1	2026-08-10 07:05:33.003816+00
\.


--
-- Data for Name: findings; Type: TABLE DATA; Schema: public; Owner: auditforge
--

COPY public.findings (id, engagement_id, source_upload_id, title, description, severity, status, cvss_score, cwe, ai_generated, created_at, updated_at, fingerprint, occurrences, sources, owasp, cvss_vector, cve, ai_model, ai_prompt_version, ai_draft, priority, priority_score, final_narrative, narrative_edited, reviewed_by, reviewed_at) FROM stdin;
153	17	107	Port terbuka 443/tcp — https	Target: 192.0.2.10:443/tcp\n\nLayanan: https (nginx 1.14.0)	info	draft	\N	\N	t	2026-08-03 01:45:40.294052+00	2026-08-03 01:46:49.466794+00	88a10f84786b2ab450631d6c817baf3cada010e5	1	[{"tool": "nmap", "upload_id": 107}]	\N	\N	[]	google/gemma-4-26b-a4b-it:free	narrative-v1	{"description": "Terdeteksi port 443/tcp terbuka pada target 192.0.2.10 yang menjalankan layanan HTTPS melalui web server nginx versi 1.14.0. Port ini merupakan port standar untuk lalu lintas HTTPS yang terenkripsi.", "impact": "Port yang terbuka dapat menjadi titik masuk potensial untuk serangan terhadap layanan web jika terdapat kerentanan pada konfigurasi atau versi layanan yang digunakan. Risiko ini umumnya bersifat informasional dalam konteks pemindaian permukaan serangan.", "recommendation": "Pastikan layanan HTTPS dikonfigurasi dengan standar keamanan terkini dan pastikan versi nginx yang digunakan telah diperbarui untuk menghindari kerentanan yang diketahui pada versi lama."}	4	5	\N	f	\N	\N
152	17	107	Port terbuka 22/tcp — ssh	Target: 192.0.2.10:22/tcp\n\nLayanan: ssh (OpenSSH 7.4)	info	approved	\N	\N	t	2026-08-03 01:45:40.294046+00	2026-08-10 03:02:44.836138+00	3d5f1e3df55bc867e3afe2ed448d68f258a12b08	1	[{"tool": "nmap", "upload_id": 107}]	\N	\N	[]	google/gemma-4-26b-a4b-it:free	narrative-v1	{"description": "Ditemukan port 22/tcp yang terbuka pada 192.0.2.10 yang menjalankan layanan OpenSSH versi 7.4. Port ini merupakan layanan standar untuk protokol Secure Shell (SSH) yang digunakan untuk akses administratif jarak jauh.", "impact": "Meskipun bersifat informasi, port yang terbuka meningkatkan permukaan serangan bagi aktor ancaman untuk mencoba melakukan autentikasi paksa atau eksploitasi terhadap layanan tersebut.", "recommendation": "Pastikan layanan SSH hanya dapat diakses dari jaringan internal yang terpercaya dan pastikan versi OpenSSH telah diperbarui ke versi terbaru yang mendukung patch keamanan terkini."}	4	5	\N	f	1	2026-08-10 03:02:44.835247+00
154	17	107	Nmap script: ssl-enum-ciphers	Target: 192.0.2.10:443/tcp\n\nTLSv1.0 supported (weak cipher suites offered)	info	draft	\N	\N	t	2026-08-03 01:45:40.294054+00	2026-08-03 01:46:34.430237+00	402d9ed0e58747e356eac75be75428af28eb6045	1	[{"tool": "nmap", "upload_id": 107}]	\N	\N	[]	google/gemma-4-26b-a4b-it:free	narrative-v1	{"description": "Hasil pemindaian menunjukkan bahwa layanan pada 192.0.2.10 mendukung protokol TLSv1.0. Protokol ini menggunakan suite kriptografi yang lemah dan dianggap sudah usang.", "impact": "Penggunaan protokol TLS yang usang memungkinkan penyerang melakukan serangan downgrade atau eksploitasi pada enkripsi yang lemah. Hal ini dapat mengakibatkan kebocoran data sensitif selama proses transmisi.", "recommendation": "Nonaktifkan dukungan untuk TLSv1.0 dan TLSv1.1 pada layanan 192.0.2.10. Implementasikan penggunaan TLSv1.2 atau versi yang lebih baru untuk memastikan standar keamanan yang memadai."}	4	5	\N	f	\N	\N
155	17	107	Nmap script: ssl-heartbleed	Target: 192.0.2.10:443/tcp\n\nVULNERABLE: The Heartbleed Bug. CVE-2014-0160 detected.\n\nReferensi: CVE-2014-0160	high	approved	7.5	CWE-125	t	2026-08-03 01:45:40.294055+00	2026-08-04 02:17:17.234228+00	97659e47590593c399429514b9e44ae0db2694c6	1	[{"tool": "nmap", "upload_id": 107}]	\N	CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N	["CVE-2014-0160"]	google/gemma-4-26b-a4b-it:free	narrative-v1	{"description": "Sistem teridentifikasi rentan terhadap kerentanan Heartbleed (CVE-2014-0160) pada layanan SSL/TLS di 192.0.2.10:443/tcp. Kerentanan ini terjadi akibat kesalahan implementasi pada ekstensi Heartbeat dalam protokol TLS yang memungkinkan pembacaan memori server secara tidak sah.", "impact": "Eksploitasi kerentanan ini dapat menyebabkan kebocoran informasi sensitif dari memori server, termasuk kredensial pengguna, kunci enkripsi, maupun data rahasia lainnya, yang dapat digunakan untuk mengambil alih sesi komunikasi.", "recommendation": "Segera lakukan pembaruan (patching) pada pustaka OpenSSL ke versi yang telah memperbaiki kerentanan ini. Selain itu, disarankan untuk melakukan rotasi sertifikat SSL/TLS dan kredensial yang berisiko telah terkompromi."}	1	107.5	\N	f	1	2026-08-04 02:17:17.233901+00
157	17	108	Mixed Content	Target: https://example.com/page\n\nHalaman HTTPS memuat sumber daya HTTP.\n\nReferensi: https://owasp.org/mixed-content	low	approved	\N	CWE-311	t	2026-08-03 01:53:16.442839+00	2026-08-04 03:44:56.443397+00	9cd6844feb8ce1cc0b31c94969aa9520149f86f9	3	[{"tool": "nuclei", "upload_id": 108}, {"tool": "nuclei", "upload_id": 110}]	A02:2021 – Cryptographic Failures	\N	[]	google/gemma-4-26b-a4b-it:free	narrative-v1	{"description": "Halaman web yang diakses melalui protokol HTTPS pada https://example.com/page memuat sumber daya (seperti skrip, gambar, atau gaya) menggunakan protokol HTTP yang tidak aman. Hal ini menyebabkan ketidakkonsistenan pada koneksi terenkripsi yang seharusnya diterapkan secara menyeluruh pada halaman tersebut.", "impact": "Eksploitasi terhadap mixed content dapat memungkinkan penyerang melakukan serangan Man-in-the-Middle (MitM) untuk menyuntikkan konten berbahaya atau melakukan sniffing terhadap data yang dikirimkan melalui koneksi HTTP yang tidak terenkripsi tersebut.", "recommendation": "Perbarui semua referensi sumber daya dalam kode HTML agar menggunakan protokol HTTPS secara konsisten. Implementasikan kebijakan Content Security Policy (CSP) dengan direktif 'upgrade-insecure-requests' untuk memaksa browser memuat semua sumber daya melalui HTTPS."}	4	23	\N	f	1	2026-08-04 02:17:30.43246+00
156	17	108	TLS Version Detection	Target: example.com:443\n\nMendeteksi versi TLS yang didukung server.\n\nReferensi: https://tls.example.com	info	draft	\N	CWE-200	t	2026-08-03 01:53:16.442836+00	2026-08-04 03:44:56.443394+00	00be1e40bee76f2ea78078d04f1e1bf33443b66f	3	[{"tool": "nuclei", "upload_id": 108}, {"tool": "nuclei", "upload_id": 110}]	A01:2021 – Broken Access Control	\N	[]	google/gemma-4-26b-a4b-it:free	narrative-v1	{"description": "Sistem terdeteksi mendukung berbagai versi protokol TLS saat melakukan komunikasi pada target example.com:443. Deteksi versi protokol ini memungkinkan penyerang untuk mengetahui konfigurasi enkripsi yang digunakan oleh server.", "impact": "Informasi mengenai versi TLS yang didukung dapat membantu penyerang dalam menentukan kerentanan spesifik pada protokol tersebut untuk melakukan serangan downgrade atau penyadapan komunikasi.", "recommendation": "Lakukan audit terhadap konfigurasi SSL/TLS pada server dan pastikan hanya versi TLS yang aman (seperti TLS 1.2 atau TLS 1.3) yang diaktifkan, serta menonaktifkan versi protokol yang sudah usang."}	4	13	\N	f	\N	\N
158	17	108	Apache Log4j2 Remote Code Execution (Log4Shell)	Target: https://example.com/api/login\n\nKerentanan RCE Log4Shell pada Apache Log4j2.\n\nReferensi: https://nvd.nist.gov/vuln/detail/CVE-2021-44228	critical	approved	10	CWE-502	t	2026-08-03 01:53:16.44284+00	2026-08-04 03:44:56.443398+00	c8aef17d37ab0b7b34f23bd22184307a00e982af	3	[{"tool": "nuclei", "upload_id": 108}, {"tool": "nuclei", "upload_id": 110}]	A08:2021 – Software and Data Integrity Failures	CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H	["CVE-2021-44228"]	google/gemma-4-26b-a4b-it:free	narrative-v1	{"description": "Aplikasi yang berjalan pada https://example.com/api/login menggunakan pustaka Apache Log4j2 yang rentan terhadap kerentanan remote code execution (RCE) melalui fitur JNDI lookup. Penyerang dapat menyisipkan string manipulasi pada parameter input yang akan dieksekusi oleh pustaka tersebut, memungkinkan eksekusi kode arbitrer pada server.", "impact": "Eksploitasi kerentanan ini memungkinkan penyerang untuk mengambil kendali penuh atas server, mencuri data sensitif, atau melakukan pergerakan lateral di dalam jaringan internal. Hal ini menimbulkan risiko keamanan tingkat kritis terhadap integritas dan kerahasiaan sistem.", "recommendation": "Segera perbarui pustaka Apache Log4j2 ke versi terbaru yang telah menambal kerentanan ini (minimal versi 2.17.1 untuk Java 8). Jika pembaruan tidak dapat dilakukan segera, nonaktifkan fitur lookup melalui konfigurasi sistem atau gunakan mitigasi berbasis WAF."}	1	153	{"description": "Aplikasi yang berjalan pada https://example.com/api/login menggunakan pustaka Apache Log4j2 yang rentan terhadap kerentanan remote code execution (RCE) melalui fitur JNDI lookup. Penyerang dapat memasukkan string manipulasi pada parameter input yang akan dieksekusi oleh pustaka tersebut, memungkinkan eksekusi kode arbitrer pada server.", "impact": "Eksploitasi kerentanan ini memungkinkan penyerang untuk mengambil kontrol penuh atas server, mencuri data sensitif, atau melakukan pergerakan lateral di dalam jaringan internal. Hal ini menimbulkan risiko keamanan tingkat kritis terhadap integritas dan kerahasiaan sistem.", "recommendation": "Segera perbarui pustaka Apache Log4j2 ke versi terbaru yang telah menambal kerentanan ini (minimal versi 2.17.1 untuk Java 8). Jika pembaruan tidak dapat dilakukan segera, nonaktifkan fitur lookup melalui konfigurasi sistem atau gunakan mitigasi berbasis WAF."}	t	1	2026-08-04 02:17:02.738689+00
159	17	111	Absence of Anti-CSRF Tokens	Target: http://example.com/login\n\nNo Anti-CSRF tokens were found in a HTML submission form.\n\nReferensi: https://owasp.org/www-community/attacks/csrf	low	draft	\N	CWE-352	f	2026-08-04 03:38:51.926999+00	2026-08-04 03:38:51.927002+00	be3bea3e3eb432d60c47f149d076aea19cfc6cbc	1	[{"tool": "zap", "upload_id": 111}]	A01:2021 – Broken Access Control	\N	[]	\N	\N	\N	4	15	\N	f	\N	\N
160	17	111	Cross Site Scripting (Reflected)	Target: http://example.com/search?q=test\n\nCross-site Scripting (XSS) terpantul pada parameter pencarian.\n\nReferensi: https://owasp.org/www-community/attacks/xss/	high	draft	\N	CWE-79	f	2026-08-04 03:38:51.927003+00	2026-08-04 03:38:51.927004+00	15ce5b3b567980dd66c77dea2e30259238bd1cc8	1	[{"tool": "zap", "upload_id": 111}]	A03:2021 – Injection	\N	[]	\N	\N	\N	2	70	\N	f	\N	\N
161	17	112	Hardcoded Secret	Target: app/config.py:12\n\nHardcoded API key found in source.	high	draft	7.5	CWE-798	f	2026-08-04 04:45:09.365151+00	2026-08-04 04:45:09.365157+00	fea75f12d4dfc0aeca3fb2c0ea2cb2ad84aae06d	1	[{"tool": "sarif", "upload_id": 112}]	A07:2021 – Identification and Authentication Failures	\N	[]	\N	\N	\N	1	92.5	\N	f	\N	\N
162	17	112	Weak Hash (MD5)	Target: app/util.py:30\n\nMD5 is a weak hashing algorithm; use SHA-256.	medium	draft	4	CWE-327	f	2026-08-04 04:45:09.365159+00	2026-08-04 04:45:09.36516+00	bbc1d6147eec9d6a504e5af770af702ef696d5ac	1	[{"tool": "sarif", "upload_id": 112}]	A02:2021 – Cryptographic Failures	\N	[]	\N	\N	\N	3	52	\N	f	\N	\N
163	18	113	TLS Version Detection	Target: example.com:443\n\nMendeteksi versi TLS yang didukung server.\n\nReferensi: https://tls.example.com	info	approved	\N	CWE-200	t	2026-08-04 06:10:24.994929+00	2026-08-04 06:13:16.359443+00	00be1e40bee76f2ea78078d04f1e1bf33443b66f	1	[{"tool": "nuclei", "upload_id": 113}]	A01:2021 – Broken Access Control	\N	[]	google/gemma-4-26b-a4b-it:free	narrative-v1	{"description": "Sistem terdeteksi mendukung protokol Transport Layer Security (TLS) yang dapat diidentifikasi melalui pemeriksaan pada target example.com:443. Informasi versi TLS yang tersedia dapat memberikan petunjuk mengenai konfigurasi keamanan server kepada pihak luar.", "impact": "Meskipun hanya bersifat informatif, pengungkapan versi protokol dapat membantu penyerang dalam memetakan permukaan serangan dan menentukan potensi kerentanan pada versi TLS yang digunakan.", "recommendation": "Pastikan hanya versi TLS yang kuat dan aman (seperti TLS 1.2 atau 1.3) yang diaktifkan, serta pertimbangkan untuk menyembunyikan informasi detail versi protokol pada respons server jika memungkinkan."}	4	5	\N	f	1	2026-08-04 06:13:16.359273+00
166	18	115	Absence of Anti-CSRF Tokens	Target: http://example.com/login\n\nNo Anti-CSRF tokens were found in a HTML submission form.\n\nReferensi: https://owasp.org/www-community/attacks/csrf	low	approved	\N	CWE-352	t	2026-08-04 06:11:00.303415+00	2026-08-04 06:13:21.308101+00	be3bea3e3eb432d60c47f149d076aea19cfc6cbc	1	[{"tool": "zap", "upload_id": 115}]	A01:2021 – Broken Access Control	\N	[]	google/gemma-4-26b-a4b-it:free	narrative-v1	{"description": "Formulir pengiriman HTML pada endpoint http://example.com/login tidak menyertakan token Anti-CSRF. Hal ini terjadi karena tidak adanya mekanisme validasi unik untuk memverifikasi bahwa permintaan formulir berasal dari pengguna yang sah melalui sesi yang valid.", "impact": "Tanpa perlindungan Anti-CSRF, penyerang dapat melakukan serangan Cross-Site Request Forgery (CSRF) untuk memanipulasi permintaan dari pengguna yang terautentikasi. Hal ini dapat menyebabkan tindakan yang tidak sah, seperti perubahan kredensial atau aktivasi akun tanpa sepengetahuan pengguna.", "recommendation": "Implementasikan token Anti-CSRF yang unik dan sulit ditebak untuk setiap sesi pengguna dalam setiap formulir HTML. Selain itu, gunakan validasi berbasis SameSite cookie attributes untuk memberikan lapisan perlindungan tambahan."}	4	15	\N	f	1	2026-08-04 06:13:21.307928+00
168	19	116	TLS Version Detection	Target: example.com:443\n\nMendeteksi versi TLS yang didukung server.\n\nReferensi: https://tls.example.com	info	approved	\N	CWE-200	t	2026-08-10 04:52:25.850902+00	2026-08-10 06:24:32.349395+00	00be1e40bee76f2ea78078d04f1e1bf33443b66f	1	[{"tool": "nuclei", "upload_id": 116}]	A01:2021 – Broken Access Control	\N	[]	google/gemma-4-26b-a4b-it:free	narrative-v1	{"description": "Server pada target example.com:443 terdeteksi mengizinkan penggunaan protokol TLS untuk enkripsi komunikasi. Deteksi versi TLS ini memberikan informasi mengenai protokol yang didukung oleh server kepada pihak luar.", "impact": "Informasi mengenai versi TLS yang didukung dapat membantu penyerang dalam memetakan profil keamanan server dan menentukan potensi kerentanan pada protokol yang digunakan.", "recommendation": "Pastikan server dikonfigurasi untuk hanya mendukung versi TLS yang aman (misalnya TLS 1.2 atau TLS 1.3) dan menonaktifkan versi TLS yang sudah usang."}	4	5	\N	f	1	2026-08-10 06:24:32.347133+00
165	18	113	Apache Log4j2 Remote Code Execution (Log4Shell)	Target: https://example.com/api/login\n\nKerentanan RCE Log4Shell pada Apache Log4j2.\n\nReferensi: https://nvd.nist.gov/vuln/detail/CVE-2021-44228	critical	approved	10	CWE-502	t	2026-08-04 06:10:24.994935+00	2026-08-04 06:26:13.258314+00	c8aef17d37ab0b7b34f23bd22184307a00e982af	1	[{"tool": "nuclei", "upload_id": 113}]	A08:2021 – Software and Data Integrity Failures	CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H	["CVE-2021-44228"]	google/gemma-4-26b-a4b-it:free	narrative-v1	{"description": "Terdeteksi kerentanan Remote Code Execution (RCE) pada komponen Apache Log4j2 di endpoint https://example.com/api/login akibat mekanisme lookup JNDI yang tidak aman. Penyerang dapat mengeksploitasi kerentanan ini dengan mengirimkan string khusus dalam input yang akan dieksekusi oleh pustaka log tersebut. Celah ini merupakan implementasi dari CWE-502 terkait deserialisasi data yang tidak aman.", "impact": "Penyerang dapat mengeksekusi perintah arbitrer pada server target, yang dapat menyebabkan pengambilalihan kendali penuh atas sistem, pencurian data sensitif, atau eskalasi hak akses. Tingkat keparahan dikategorikan sebagai Critical dengan skor CVSS 10.0.", "recommendation": "Segera lakukan pembaruan (upgrade) pada pustaka Apache Log4j2 ke versi terbaru yang telah menambal celah keamanan ini. Selain itu, pertimbangkan untuk menerapkan aturan WAF (Web Application Firewall) untuk memfilter upaya eksploitasi berbasis JNDI lookup."}	1	145	{"description": "Terdeteksi kerentanan Remote Code Execution (RCE) pada komponen Apache Log4j2 di endpoint https://example.com/api/login akibat mekanisme lookup JNDI yang tidak aman. Penyerang dapat mengeksploitasi kerentanan ini dengan mengirim string khusus dalam input yang akan dieksekusi oleh pustaka log tersebut. Celah ini merupakan implementasi dari CWE-502 terkait deserialisasi data yang tidak aman.", "impact": "Penyerang dapat menjalankan perintah arbitrer pada server target, yang dapat menyebabkan pengambilalihan kendali penuh atas sistem, pencurian data sensitif, atau eskalasi hak akses. Tingkat keparahan dikategorikan sebagai Critical dengan skor CVSS 10.0.", "recommendation": "Segera lakukan pembaruan (upgrade) pada pustaka Apache Log4j2 ke versi terbaru yang telah menutup celah keamanan ini. Selain itu, pertimbangkan untuk menerapkan aturan WAF (Web Application Firewall) untuk memfilter upaya eksploitasi berbasis JNDI lookup."}	t	1	2026-08-04 06:12:59.924465+00
164	18	113	Mixed Content	Target: https://example.com/page\n\nHalaman HTTPS memuat sumber daya HTTP.\n\nReferensi: https://owasp.org/mixed-content	low	approved	\N	CWE-311	t	2026-08-04 06:10:24.994934+00	2026-08-10 02:51:21.852835+00	9cd6844feb8ce1cc0b31c94969aa9520149f86f9	1	[{"tool": "nuclei", "upload_id": 113}]	A02:2021 – Cryptographic Failures	\N	[]	google/gemma-4-26b-a4b-it:free	narrative-v1	{"description": "Halaman web yang diakses melalui protokol HTTPS pada https://example.com/page memuat sumber daya melalui protokol HTTP yang tidak terenkripsi. Kondisi mixed content ini menyebabkan komunikasi antara klien dan server untuk sumber daya tersebut tidak terlindungi oleh enkripsi SSL/TLS.", "impact": "Penyerang dapat melakukan serangan Man-in-the-Middle (MitM) untuk mencegat atau memodifikasi data yang dikirimkan melalui sumber daya HTTP tersebut. Hal ini dapat menyebabkan kebocoran informasi sensitif atau manipulasi konten pada halaman yang seharusnya aman.", "recommendation": "Perbarui seluruh URL sumber daya (seperti skrip, gambar, atau stylesheet) agar menggunakan protokol HTTPS. Implementasikan kebijakan Content Security Policy (CSP) dengan direktif 'upgrade-insecure-requests' untuk memaksa pemuatan sumber daya melalui HTTPS."}	4	15	{"description": "Halaman web yang diakses melalui protokol HTTPS pada https://example.com/page memuat sumber daya (seperti skrip, gambar, atau gaya) menggunakan protokol HTTP yang tidak aman. Hal ini menyebabkan ketidakkonsistenan pada koneksi terenkripsi yang seharusnya diterapkan secara menyeluruh pada halaman tersebut.", "impact": "Eksploitasi terhadap mixed content dapat memungkinkan penyerang melakukan serangan Man-in-the-Middle (MitM) untuk menyuntikkan konten berbahaya atau melakukan sniffing terhadap data yang dikirimkan melalui koneksi HTTP yang tidak terenkripsi tersebut.", "recommendation": "Perbarui semua referensi sumber daya dalam kode HTML agar menggunakan protokol HTTPS secara konsisten. Implementasikan kebijakan Content Security Policy (CSP) dengan direktif 'upgrade-insecure-requests' untuk memaksa browser memuat semua sumber daya melalui HTTPS."}	t	1	2026-08-04 06:13:10.989604+00
170	19	116	Apache Log4j2 Remote Code Execution (Log4Shell)	Target: https://example.com/api/login\n\nKerentanan RCE Log4Shell pada Apache Log4j2.\n\nReferensi: https://nvd.nist.gov/vuln/detail/CVE-2021-44228	critical	approved	10	CWE-502	t	2026-08-10 04:52:25.850907+00	2026-08-10 07:05:33.000957+00	c8aef17d37ab0b7b34f23bd22184307a00e982af	1	[{"tool": "nuclei", "upload_id": 116}]	A08:2021 – Software and Data Integrity Failures	CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H	["CVE-2021-44228"]	google/gemma-4-26b-a4b-it:free	narrative-v1	{"description": "Ditemukan kerentanan Remote Code Execution (RCE) pada komponen Apache Log4j2 yang terletak di endpoint https://example.com/api/login. Kerentanan ini disebabkan oleh fitur lookup JNDI yang tidak aman, yang memungkinkan penyerang mengeksekusi kode arbitrer melalui manipulasi input yang kemudian diproses oleh library Log4j2.", "impact": "Penyerang dapat mengeksekusi kode secara jarak jauh pada server, yang dapat mengakibatkan pengambilalihan kendali sistem secara penuh, pencurian data sensitif, atau eskalasi hak akses. Kerentanan ini memiliki tingkat keparahan critical dengan skor CVSS 10.0.", "recommendation": "Segera lakukan pembaruan (update) Apache Log4j2 ke versi terbaru yang telah menambal celah keamanan ini (minimal versi 2.17.1 untuk Java 8). Jika pembaruan tidak memungkinkan, pertimbangkan untuk menonaktifkan konfigurasi lookup JNDI atau menerapkan filter pada level WAF."}	1	145	{"description": "Aplikasi yang berjalan pada https://example.com/api/login menggunakan pustaka Apache Log4j2 yang rentan terhadap kerentanan remote code execution (RCE) melalui fitur JNDI lookup. Penyerang dapat memasukkan string manipulasi pada parameter input yang akan dieksekusi oleh pustaka tersebut, memungkinkan eksekusi kode arbitrer pada server.", "impact": "Eksploitasi kerentanan ini memungkinkan penyerang untuk mengambil kontrol penuh atas server, mencuri data sensitif, atau melakukan pergerakan lateral di dalam jaringan internal. Hal ini menimbulkan risiko keamanan tingkat kritis terhadap integritas dan kerahasiaan sistem.", "recommendation": "Segera perbarui pustaka Apache Log4j2 ke versi terbaru yang telah menambal kerentanan ini (minimal versi 2.17.1 untuk Java 8). Jika pembaruan tidak dapat dilakukan segera, nonaktifkan fitur lookup melalui konfigurasi sistem atau gunakan mitigasi berbasis WAF."}	t	1	2026-08-10 06:24:32.544749+00
167	18	115	Cross Site Scripting (Reflected)	Target: http://example.com/search?q=test\n\nCross-site Scripting (XSS) terpantul pada parameter pencarian.\n\nReferensi: https://owasp.org/www-community/attacks/xss/	high	approved	\N	CWE-79	t	2026-08-04 06:11:00.303419+00	2026-08-10 02:43:19.908317+00	15ce5b3b567980dd66c77dea2e30259238bd1cc8	1	[{"tool": "zap", "upload_id": 115}]	A03:2021 – Injection	\N	[]	google/gemma-4-26b-a4b-it:free	narrative-v1	{"description": "Ditemukan kerentanan Cross-Site Scripting (Reflected) pada parameter 'q' di endpoint http://example.com/search. Hal ini terjadi karena aplikasi tidak melakukan sanitasi atau encoding yang memadai terhadap input pengguna sebelum menampilkannya kembali ke halaman web.", "impact": "Penyerang dapat menyisipkan skrip berbahaya yang dieksekusi di browser korban, yang dapat mengakibatkan pencurian sesi (session hijacking), manipulasi konten halaman, atau pengalihan pengguna ke situs berbahaya.", "recommendation": "Implementasikan sanitasi input yang ketat dan gunakan context-aware output encoding pada semua data yang berasal dari parameter URL sebelum ditampilkan di browser."}	2	70	\N	f	1	2026-08-10 02:43:19.906469+00
171	19	117	Absence of Anti-CSRF Tokens	Target: http://example.com/login\n\nNo Anti-CSRF tokens were found in a HTML submission form.\n\nReferensi: https://owasp.org/www-community/attacks/csrf	low	approved	\N	CWE-352	t	2026-08-10 04:52:25.895719+00	2026-08-10 06:24:32.633015+00	be3bea3e3eb432d60c47f149d076aea19cfc6cbc	1	[{"tool": "zap", "upload_id": 117}]	A01:2021 – Broken Access Control	\N	[]	google/gemma-4-26b-a4b-it:free	narrative-v1	{"description": "Formulir pengiriman HTML pada endpoint http://example.com/login tidak menyertakan token Anti-CSRF. Hal ini menyebabkan mekanisme autentikasi tidak memiliki proteksi terhadap serangan Cross-Site Request Forgery (CSRF).", "impact": "Penyerang dapat memaksa pengguna yang terautentikasi untuk melakukan tindakan yang tidak diinginkan tanpa sepengetahuan mereka. Dalam konteks ini, risiko mencakup manipulasi sesi atau tindakan akun lainnya melalui permintaan HTTP yang terfabrikasi.", "recommendation": "Implementasikan token CSRF yang unik dan sulit ditebak untuk setiap sesi pengguna dalam setiap formulir yang bersifat mengubah status (state-changing). Pastikan token tersebut divalidasi secara ketat pada sisi server saat memproses permintaan POST."}	4	15	\N	f	1	2026-08-10 06:24:32.632394+00
169	19	116	Mixed Content	Target: https://example.com/page\n\nHalaman HTTPS memuat sumber daya HTTP.\n\nReferensi: https://owasp.org/mixed-content	low	approved	\N	CWE-311	t	2026-08-10 04:52:25.850906+00	2026-08-10 06:24:32.447806+00	9cd6844feb8ce1cc0b31c94969aa9520149f86f9	1	[{"tool": "nuclei", "upload_id": 116}]	A02:2021 – Cryptographic Failures	\N	[]	google/gemma-4-26b-a4b-it:free	narrative-v1	{"description": "Halaman web yang diakses melalui protokol HTTPS pada target https://example.com/page memuat sumber daya (seperti skrip, gambar, atau gaya) menggunakan protokol HTTP biasa. Kondisi ini menyebabkan konten tersebut dianggap sebagai 'Mixed Content' karena tidak memiliki enkripsi yang sama dengan halaman utama.", "impact": "Penyerang dapat melakukan serangan Man-in-the-Middle (MitM) untuk menyisipkan konten berbahaya atau memodifikasi sumber daya HTTP tersebut guna memanipulasi tampilan atau perilaku halaman. Hal ini dapat mengompromikan integritas data dan menurunkan kepercayaan pengguna terhadap keamanan situs.", "recommendation": "Perbarui semua referensi URL sumber daya dari protokol HTTP menjadi HTTPS. Implementasikan kebijakan 'Content Security Policy' (CSP) dengan direktif 'upgrade-insecure-requests' untuk secara otomatis memaksa permintaan ke versi HTTPS."}	4	15	\N	f	1	2026-08-10 06:24:32.447153+00
172	19	117	Cross Site Scripting (Reflected)	Target: http://example.com/search?q=test\n\nCross-site Scripting (XSS) terpantul pada parameter pencarian.\n\nReferensi: https://owasp.org/www-community/attacks/xss/	high	approved	\N	CWE-79	t	2026-08-10 04:52:25.895722+00	2026-08-10 06:24:32.721421+00	15ce5b3b567980dd66c77dea2e30259238bd1cc8	1	[{"tool": "zap", "upload_id": 117}]	A03:2021 – Injection	\N	[]	google/gemma-4-26b-a4b-it:free	narrative-v1	{"description": "Ditemukan kerentanan Cross-Site Scripting (XSS) Reflected pada parameter 'q' di URL http://example.com/search?q=test. Hal ini terjadi karena aplikasi tidak melakukan validasi atau sanitasi yang memadai terhadap input pengguna sebelum menampilkannya kembali pada halaman hasil pencarian.", "impact": "Penyerang dapat mengeksploitasi kerentanan ini untuk menjalankan skrip berbahaya di sisi klien korban, yang dapat mengakibatkan pencurian sesi (session hijacking), manipulasi konten halaman, atau pengalihan pengguna ke situs berbahaya.", "recommendation": "Terapkan sanitasi input yang ketat dan gunakan mekanisme output encoding (seperti HTML Entity Encoding) pada seluruh data yang berasal dari parameter URL sebelum ditampilkan pada browser."}	2	70	\N	f	1	2026-08-10 06:24:32.720663+00
\.


--
-- Data for Name: knowledge_entries; Type: TABLE DATA; Schema: public; Owner: auditforge
--

COPY public.knowledge_entries (id, source_finding_id, source_engagement_id, title, title_norm, cwe, owasp, severity, narrative, auditor_edited, created_by, created_at, usage_count) FROM stdin;
1	167	18	Cross Site Scripting (Reflected)	cross site scripting reflected	CWE-79	A03:2021 – Injection	high	{"description": "Ditemukan kerentanan Cross-Site Scripting (Reflected) pada parameter 'q' di endpoint http://example.com/search. Hal ini terjadi karena aplikasi tidak melakukan sanitasi atau encoding yang memadai terhadap input pengguna sebelum menampilkannya kembali ke halaman web.", "impact": "Penyerang dapat menyisipkan skrip berbahaya yang dieksekusi di browser korban, yang dapat mengakibatkan pencurian sesi (session hijacking), manipulasi konten halaman, atau pengalihan pengguna ke situs berbahaya.", "recommendation": "Implementasikan sanitasi input yang ketat dan gunakan context-aware output encoding pada semua data yang berasal dari parameter URL sebelum ditampilkan di browser."}	f	1	2026-08-10 02:42:58.851534+00	0
4	155	17	Nmap script: ssl-heartbleed	nmap script ssl heartbleed	CWE-125	\N	high	{"description": "Sistem teridentifikasi rentan terhadap kerentanan Heartbleed (CVE-2014-0160) pada layanan SSL/TLS di 192.0.2.10:443/tcp. Kerentanan ini terjadi akibat kesalahan implementasi pada ekstensi Heartbeat dalam protokol TLS yang memungkinkan pembacaan memori server secara tidak sah.", "impact": "Eksploitasi kerentanan ini dapat menyebabkan kebocoran informasi sensitif dari memori server, termasuk kredensial pengguna, kunci enkripsi, maupun data rahasia lainnya, yang dapat digunakan untuk mengambil alih sesi komunikasi.", "recommendation": "Segera lakukan pembaruan (patching) pada pustaka OpenSSL ke versi yang telah memperbaiki kerentanan ini. Selain itu, disarankan untuk melakukan rotasi sertifikat SSL/TLS dan kredensial yang berisiko telah terkompromi."}	f	1	2026-08-10 02:45:08.654551+00	0
7	163	18	TLS Version Detection	tls version	CWE-200	A01:2021 – Broken Access Control	info	{"description": "Sistem terdeteksi mendukung protokol Transport Layer Security (TLS) yang dapat diidentifikasi melalui pemeriksaan pada target example.com:443. Informasi versi TLS yang tersedia dapat memberikan petunjuk mengenai konfigurasi keamanan server kepada pihak luar.", "impact": "Meskipun hanya bersifat informatif, pengungkapan versi protokol dapat membantu penyerang dalam memetakan permukaan serangan dan menentukan potensi kerentanan pada versi TLS yang digunakan.", "recommendation": "Pastikan hanya versi TLS yang kuat dan aman (seperti TLS 1.2 atau 1.3) yang diaktifkan, serta pertimbangkan untuk menyembunyikan informasi detail versi protokol pada respons server jika memungkinkan."}	f	1	2026-08-10 02:45:08.654553+00	0
8	164	18	Mixed Content	mixed content	CWE-311	A02:2021 – Cryptographic Failures	low	{"description": "Halaman web yang diakses melalui protokol HTTPS pada https://example.com/page memuat sumber daya melalui protokol HTTP yang tidak terenkripsi. Kondisi mixed content ini menyebabkan komunikasi antara klien dan server untuk sumber daya tersebut tidak terlindungi oleh enkripsi SSL/TLS.", "impact": "Penyerang dapat melakukan serangan Man-in-the-Middle (MitM) untuk mencegat atau memodifikasi data yang dikirimkan melalui sumber daya HTTP tersebut. Hal ini dapat menyebabkan kebocoran informasi sensitif atau manipulasi konten pada halaman yang seharusnya aman.", "recommendation": "Perbarui seluruh URL sumber daya (seperti skrip, gambar, atau stylesheet) agar menggunakan protokol HTTPS. Implementasikan kebijakan Content Security Policy (CSP) dengan direktif 'upgrade-insecure-requests' untuk memaksa pemuatan sumber daya melalui HTTPS."}	f	1	2026-08-10 02:45:08.654553+00	0
9	165	18	Apache Log4j2 Remote Code Execution (Log4Shell)	apache log4j2 remote code execution log4shell	CWE-502	A08:2021 – Software and Data Integrity Failures	critical	{"description": "Terdeteksi kerentanan Remote Code Execution (RCE) pada komponen Apache Log4j2 di endpoint https://example.com/api/login akibat mekanisme lookup JNDI yang tidak aman. Penyerang dapat mengeksploitasi kerentanan ini dengan mengirim string khusus dalam input yang akan dieksekusi oleh pustaka log tersebut. Celah ini merupakan implementasi dari CWE-502 terkait deserialisasi data yang tidak aman.", "impact": "Penyerang dapat menjalankan perintah arbitrer pada server target, yang dapat menyebabkan pengambilalihan kendali penuh atas sistem, pencurian data sensitif, atau eskalasi hak akses. Tingkat keparahan dikategorikan sebagai Critical dengan skor CVSS 10.0.", "recommendation": "Segera lakukan pembaruan (upgrade) pada pustaka Apache Log4j2 ke versi terbaru yang telah menutup celah keamanan ini. Selain itu, pertimbangkan untuk menerapkan aturan WAF (Web Application Firewall) untuk memfilter upaya eksploitasi berbasis JNDI lookup."}	t	1	2026-08-10 02:45:08.654553+00	0
6	158	17	Apache Log4j2 Remote Code Execution (Log4Shell)	apache log4j2 remote code execution log4shell	CWE-502	A08:2021 – Software and Data Integrity Failures	critical	{"description": "Aplikasi yang berjalan pada https://example.com/api/login menggunakan pustaka Apache Log4j2 yang rentan terhadap kerentanan remote code execution (RCE) melalui fitur JNDI lookup. Penyerang dapat memasukkan string manipulasi pada parameter input yang akan dieksekusi oleh pustaka tersebut, memungkinkan eksekusi kode arbitrer pada server.", "impact": "Eksploitasi kerentanan ini memungkinkan penyerang untuk mengambil kontrol penuh atas server, mencuri data sensitif, atau melakukan pergerakan lateral di dalam jaringan internal. Hal ini menimbulkan risiko keamanan tingkat kritis terhadap integritas dan kerahasiaan sistem.", "recommendation": "Segera perbarui pustaka Apache Log4j2 ke versi terbaru yang telah menambal kerentanan ini (minimal versi 2.17.1 untuk Java 8). Jika pembaruan tidak dapat dilakukan segera, nonaktifkan fitur lookup melalui konfigurasi sistem atau gunakan mitigasi berbasis WAF."}	t	1	2026-08-10 02:45:08.654552+00	1
10	166	18	Absence of Anti-CSRF Tokens	absence anti csrf tokens	CWE-352	A01:2021 – Broken Access Control	low	{"description": "Formulir pengiriman HTML pada endpoint http://example.com/login tidak menyertakan token Anti-CSRF. Hal ini terjadi karena tidak adanya mekanisme validasi unik untuk memverifikasi bahwa permintaan formulir berasal dari pengguna yang sah melalui sesi yang valid.", "impact": "Tanpa perlindungan Anti-CSRF, penyerang dapat melakukan serangan Cross-Site Request Forgery (CSRF) untuk memanipulasi permintaan dari pengguna yang terautentikasi. Hal ini dapat menyebabkan tindakan yang tidak sah, seperti perubahan kredensial atau aktivasi akun tanpa sepengetahuan pengguna.", "recommendation": "Implementasikan token Anti-CSRF yang unik dan sulit ditebak untuk setiap sesi pengguna dalam setiap formulir HTML. Selain itu, gunakan validasi berbasis SameSite cookie attributes untuk memberikan lapisan perlindungan tambahan."}	f	1	2026-08-10 02:45:08.654554+00	0
5	157	17	Mixed Content	mixed content	CWE-311	A02:2021 – Cryptographic Failures	low	{"description": "Halaman web yang diakses melalui protokol HTTPS pada https://example.com/page memuat sumber daya (seperti skrip, gambar, atau gaya) menggunakan protokol HTTP yang tidak aman. Hal ini menyebabkan ketidakkonsistenan pada koneksi terenkripsi yang seharusnya diterapkan secara menyeluruh pada halaman tersebut.", "impact": "Eksploitasi terhadap mixed content dapat memungkinkan penyerang melakukan serangan Man-in-the-Middle (MitM) untuk menyuntikkan konten berbahaya atau melakukan sniffing terhadap data yang dikirimkan melalui koneksi HTTP yang tidak terenkripsi tersebut.", "recommendation": "Perbarui semua referensi sumber daya dalam kode HTML agar menggunakan protokol HTTPS secara konsisten. Implementasikan kebijakan Content Security Policy (CSP) dengan direktif 'upgrade-insecure-requests' untuk memaksa browser memuat semua sumber daya melalui HTTPS."}	f	1	2026-08-10 02:45:08.654552+00	1
11	168	19	TLS Version Detection	tls version	CWE-200	A01:2021 – Broken Access Control	info	{"description": "Server pada target example.com:443 terdeteksi mengizinkan penggunaan protokol TLS untuk enkripsi komunikasi. Deteksi versi TLS ini memberikan informasi mengenai protokol yang didukung oleh server kepada pihak luar.", "impact": "Informasi mengenai versi TLS yang didukung dapat membantu penyerang dalam memetakan profil keamanan server dan menentukan potensi kerentanan pada protokol yang digunakan.", "recommendation": "Pastikan server dikonfigurasi untuk hanya mendukung versi TLS yang aman (misalnya TLS 1.2 atau TLS 1.3) dan menonaktifkan versi TLS yang sudah usang."}	f	1	2026-08-10 06:24:32.352452+00	0
12	169	19	Mixed Content	mixed content	CWE-311	A02:2021 – Cryptographic Failures	low	{"description": "Halaman web yang diakses melalui protokol HTTPS pada target https://example.com/page memuat sumber daya (seperti skrip, gambar, atau gaya) menggunakan protokol HTTP biasa. Kondisi ini menyebabkan konten tersebut dianggap sebagai 'Mixed Content' karena tidak memiliki enkripsi yang sama dengan halaman utama.", "impact": "Penyerang dapat melakukan serangan Man-in-the-Middle (MitM) untuk menyisipkan konten berbahaya atau memodifikasi sumber daya HTTP tersebut guna memanipulasi tampilan atau perilaku halaman. Hal ini dapat mengompromikan integritas data dan menurunkan kepercayaan pengguna terhadap keamanan situs.", "recommendation": "Perbarui semua referensi URL sumber daya dari protokol HTTP menjadi HTTPS. Implementasikan kebijakan 'Content Security Policy' (CSP) dengan direktif 'upgrade-insecure-requests' untuk secara otomatis memaksa permintaan ke versi HTTPS."}	f	1	2026-08-10 06:24:32.448652+00	0
13	170	19	Apache Log4j2 Remote Code Execution (Log4Shell)	apache log4j2 remote code execution log4shell	CWE-502	A08:2021 – Software and Data Integrity Failures	critical	{"description": "Ditemukan kerentanan Remote Code Execution (RCE) pada komponen Apache Log4j2 yang terletak di endpoint https://example.com/api/login. Kerentanan ini disebabkan oleh fitur lookup JNDI yang tidak aman, yang memungkinkan penyerang mengeksekusi kode arbitrer melalui manipulasi input yang kemudian diproses oleh library Log4j2.", "impact": "Penyerang dapat mengeksekusi kode secara jarak jauh pada server, yang dapat mengakibatkan pengambilalihan kendali sistem secara penuh, pencurian data sensitif, atau eskalasi hak akses. Kerentanan ini memiliki tingkat keparahan critical dengan skor CVSS 10.0.", "recommendation": "Segera lakukan pembaruan (update) Apache Log4j2 ke versi terbaru yang telah menambal celah keamanan ini (minimal versi 2.17.1 untuk Java 8). Jika pembaruan tidak memungkinkan, pertimbangkan untuk menonaktifkan konfigurasi lookup JNDI atau menerapkan filter pada level WAF."}	f	1	2026-08-10 06:24:32.54644+00	0
14	171	19	Absence of Anti-CSRF Tokens	absence anti csrf tokens	CWE-352	A01:2021 – Broken Access Control	low	{"description": "Formulir pengiriman HTML pada endpoint http://example.com/login tidak menyertakan token Anti-CSRF. Hal ini menyebabkan mekanisme autentikasi tidak memiliki proteksi terhadap serangan Cross-Site Request Forgery (CSRF).", "impact": "Penyerang dapat memaksa pengguna yang terautentikasi untuk melakukan tindakan yang tidak diinginkan tanpa sepengetahuan mereka. Dalam konteks ini, risiko mencakup manipulasi sesi atau tindakan akun lainnya melalui permintaan HTTP yang terfabrikasi.", "recommendation": "Implementasikan token CSRF yang unik dan sulit ditebak untuk setiap sesi pengguna dalam setiap formulir yang bersifat mengubah status (state-changing). Pastikan token tersebut divalidasi secara ketat pada sisi server saat memproses permintaan POST."}	f	1	2026-08-10 06:24:32.633879+00	0
15	172	19	Cross Site Scripting (Reflected)	cross site scripting reflected	CWE-79	A03:2021 – Injection	high	{"description": "Ditemukan kerentanan Cross-Site Scripting (XSS) Reflected pada parameter 'q' di URL http://example.com/search?q=test. Hal ini terjadi karena aplikasi tidak melakukan validasi atau sanitasi yang memadai terhadap input pengguna sebelum menampilkannya kembali pada halaman hasil pencarian.", "impact": "Penyerang dapat mengeksploitasi kerentanan ini untuk menjalankan skrip berbahaya di sisi klien korban, yang dapat mengakibatkan pencurian sesi (session hijacking), manipulasi konten halaman, atau pengalihan pengguna ke situs berbahaya.", "recommendation": "Terapkan sanitasi input yang ketat dan gunakan mekanisme output encoding (seperti HTML Entity Encoding) pada seluruh data yang berasal dari parameter URL sebelum ditampilkan pada browser."}	f	1	2026-08-10 06:24:32.722218+00	0
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: auditforge
--

COPY public.roles (id, name, description) FROM stdin;
1	admin	Peran admin
2	auditor	Peran auditor
3	analyst	Peran analyst
\.


--
-- Data for Name: scan_uploads; Type: TABLE DATA; Schema: public; Owner: auditforge
--

COPY public.scan_uploads (id, engagement_id, filename, tool, storage_key, status, uploaded_by, created_at, error, content_hash) FROM stdin;
107	17	nmap-sample.xml	nmap	uploads/17/5ee2acef62ec4d74b8368dd69b7c3458_nmap-sample.xml	parsed	1	2026-08-03 01:45:40.075531+00	\N	\N
108	17	nuclei-sample.jsonl	nuclei	uploads/17/ccbedc2ce15f4e5f93e4a9f365cfc90a_nuclei-sample.jsonl	parsed	1	2026-08-03 01:53:16.421847+00	\N	\N
117	19	zap-sample.json	zap	uploads/19/9c068287f0fb4d99a74a4fb970d41d5b_zap-sample.json	parsed	\N	2026-08-10 04:52:25.882095+00	\N	52e1a86f1d6487b1dd1e37ecf0bdc68902386d0130191428d89968a13111f7c5
111	17	zap-sample.json	zap	uploads/17/8c42608e6ee04a93b4bd760a0030fcc4_zap-sample.json	parsed	1	2026-08-04 03:38:51.802353+00	\N	52e1a86f1d6487b1dd1e37ecf0bdc68902386d0130191428d89968a13111f7c5
110	17	nuclei-sample.jsonl	nuclei	uploads/17/642a97dc3216487d83f01ab883ce3322_nuclei-sample.jsonl	parsed	\N	2026-08-03 06:22:12.268363+00	\N	\N
109	17	broken-sample.xml	unknown	uploads/17/2620fdcefeab4329aa2fe5fe779868c7_broken-sample.xml	failed	\N	2026-08-03 06:22:12.142728+00	ParseError: unclosed token: line 5, column 6	\N
112	17	sarif-sample.json	sarif	uploads/17/ea1896cd653a49d0903011f6585b20e7_sarif-sample.json	parsed	1	2026-08-04 04:45:09.154714+00	\N	a4f817e458d80091f74154f3a9f722004e940ba201a6dbbcb2b510e1504fc90c
113	18	nuclei-sample.jsonl	nuclei	uploads/18/9394257f084c4ad6888d25ccf3f33b8f_nuclei-sample.jsonl	parsed	1	2026-08-04 06:10:24.783783+00	\N	511c3f4dd448cebeb3175db2f1d2e1f7d7e858b1ba9a836eff934110ae24938a
114	18	nmap-sample.xml	nuclei	uploads/18/f67fad2e8c794b0e98b900e6da3847f7_nmap-sample.xml	parsed	1	2026-08-04 06:10:31.177947+00	\N	084d0453704d8d7263d91afba6c10cb916d59151a91ef3da8079fe2b601db410
115	18	zap-sample.json	zap	uploads/18/f476a28b06bb47d48b6fb6088c7f74bf_zap-sample.json	parsed	1	2026-08-04 06:11:00.286442+00	\N	52e1a86f1d6487b1dd1e37ecf0bdc68902386d0130191428d89968a13111f7c5
116	19	nuclei-sample.jsonl	nuclei	uploads/19/d07333747edd444fb66fbf0ffc9771e7_nuclei-sample.jsonl	parsed	\N	2026-08-10 04:52:25.801605+00	\N	511c3f4dd448cebeb3175db2f1d2e1f7d7e858b1ba9a836eff934110ae24938a
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: auditforge
--

COPY public.users (id, email, full_name, hashed_password, role_id, is_active, created_at) FROM stdin;
1	admin@auditforge.local	Administrator	$2b$12$x7B876iHRdOsaJ1E1yjY6.IJEUBXhQn8wO8Yq676T1DGT7cMLUAg6	1	t	2026-07-27 08:41:56.740876+00
2	analis@auditforge.local	Analis Satu	$2b$12$cxJ/TgiejlGedfBrXevHO.F0caveeQotiCrt8CxzvHgK8HfvcwNUC	3	t	2026-07-27 08:42:40.60006+00
3	auditor@auditforge.local	Auditor Satu	$2b$12$zX1sh7.KSo9FYHsN5xrfruxWWWEsB4L18rXQiPMkemC6kV8xCYr0a	2	t	2026-07-27 08:53:57.958221+00
4	uji_analis@auditforge.local	Uji Analis	$2b$12$W1JbMje4oKENlpnh/F6gdeTtm272DJtwLAjnB.N6du9sjdodsfzkS	3	t	2026-07-28 07:51:28.509725+00
5	uji_auditor@auditforge.local	Uji Auditor	$2b$12$bBOvJB5dcoiE0Yk/hE/NKu3MsiDKojvQFkKoLWYntk0U8vFsaEGaK	2	t	2026-07-28 07:51:28.723326+00
6	uji.analis@auditforge.local	Uji Analis	$2b$12$i0hl..GpZTNoYmiXMBoBCeNzXt2HMrhOomS3Z7mHR12nPfIfiq0ai	3	t	2026-08-04 07:05:56.611858+00
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: auditforge
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 524, true);


--
-- Name: engagement_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: auditforge
--

SELECT pg_catalog.setval('public.engagement_members_id_seq', 21, true);


--
-- Name: engagements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: auditforge
--

SELECT pg_catalog.setval('public.engagements_id_seq', 20, true);


--
-- Name: finding_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: auditforge
--

SELECT pg_catalog.setval('public.finding_attachments_id_seq', 4, true);


--
-- Name: finding_revisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: auditforge
--

SELECT pg_catalog.setval('public.finding_revisions_id_seq', 89, true);


--
-- Name: findings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: auditforge
--

SELECT pg_catalog.setval('public.findings_id_seq', 175, true);


--
-- Name: knowledge_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: auditforge
--

SELECT pg_catalog.setval('public.knowledge_entries_id_seq', 15, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: auditforge
--

SELECT pg_catalog.setval('public.roles_id_seq', 3, true);


--
-- Name: scan_uploads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: auditforge
--

SELECT pg_catalog.setval('public.scan_uploads_id_seq', 118, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: auditforge
--

SELECT pg_catalog.setval('public.users_id_seq', 6, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (key);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: engagement_members engagement_members_pkey; Type: CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.engagement_members
    ADD CONSTRAINT engagement_members_pkey PRIMARY KEY (id);


--
-- Name: engagements engagements_pkey; Type: CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.engagements
    ADD CONSTRAINT engagements_pkey PRIMARY KEY (id);


--
-- Name: finding_attachments finding_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.finding_attachments
    ADD CONSTRAINT finding_attachments_pkey PRIMARY KEY (id);


--
-- Name: finding_revisions finding_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.finding_revisions
    ADD CONSTRAINT finding_revisions_pkey PRIMARY KEY (id);


--
-- Name: findings findings_pkey; Type: CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_pkey PRIMARY KEY (id);


--
-- Name: knowledge_entries knowledge_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.knowledge_entries
    ADD CONSTRAINT knowledge_entries_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: scan_uploads scan_uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.scan_uploads
    ADD CONSTRAINT scan_uploads_pkey PRIMARY KEY (id);


--
-- Name: engagement_members uq_engagement_member; Type: CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.engagement_members
    ADD CONSTRAINT uq_engagement_member UNIQUE (engagement_id, user_id);


--
-- Name: knowledge_entries uq_knowledge_source_finding; Type: CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.knowledge_entries
    ADD CONSTRAINT uq_knowledge_source_finding UNIQUE (source_finding_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_engagement_members_engagement_id; Type: INDEX; Schema: public; Owner: auditforge
--

CREATE INDEX ix_engagement_members_engagement_id ON public.engagement_members USING btree (engagement_id);


--
-- Name: ix_engagement_members_user_id; Type: INDEX; Schema: public; Owner: auditforge
--

CREATE INDEX ix_engagement_members_user_id ON public.engagement_members USING btree (user_id);


--
-- Name: ix_finding_attachments_finding_id; Type: INDEX; Schema: public; Owner: auditforge
--

CREATE INDEX ix_finding_attachments_finding_id ON public.finding_attachments USING btree (finding_id);


--
-- Name: ix_finding_revisions_finding_id; Type: INDEX; Schema: public; Owner: auditforge
--

CREATE INDEX ix_finding_revisions_finding_id ON public.finding_revisions USING btree (finding_id);


--
-- Name: ix_findings_fingerprint; Type: INDEX; Schema: public; Owner: auditforge
--

CREATE INDEX ix_findings_fingerprint ON public.findings USING btree (fingerprint);


--
-- Name: ix_knowledge_entries_cwe; Type: INDEX; Schema: public; Owner: auditforge
--

CREATE INDEX ix_knowledge_entries_cwe ON public.knowledge_entries USING btree (cwe);


--
-- Name: ix_knowledge_entries_source_engagement_id; Type: INDEX; Schema: public; Owner: auditforge
--

CREATE INDEX ix_knowledge_entries_source_engagement_id ON public.knowledge_entries USING btree (source_engagement_id);


--
-- Name: ix_knowledge_entries_source_finding_id; Type: INDEX; Schema: public; Owner: auditforge
--

CREATE INDEX ix_knowledge_entries_source_finding_id ON public.knowledge_entries USING btree (source_finding_id);


--
-- Name: ix_knowledge_entries_title_norm; Type: INDEX; Schema: public; Owner: auditforge
--

CREATE INDEX ix_knowledge_entries_title_norm ON public.knowledge_entries USING btree (title_norm);


--
-- Name: ix_roles_name; Type: INDEX; Schema: public; Owner: auditforge
--

CREATE UNIQUE INDEX ix_roles_name ON public.roles USING btree (name);


--
-- Name: ix_scan_uploads_content_hash; Type: INDEX; Schema: public; Owner: auditforge
--

CREATE INDEX ix_scan_uploads_content_hash ON public.scan_uploads USING btree (content_hash);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: auditforge
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: engagement_members engagement_members_added_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.engagement_members
    ADD CONSTRAINT engagement_members_added_by_fkey FOREIGN KEY (added_by) REFERENCES public.users(id);


--
-- Name: engagement_members engagement_members_engagement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.engagement_members
    ADD CONSTRAINT engagement_members_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES public.engagements(id);


--
-- Name: engagement_members engagement_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.engagement_members
    ADD CONSTRAINT engagement_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: engagements engagements_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.engagements
    ADD CONSTRAINT engagements_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: finding_attachments finding_attachments_finding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.finding_attachments
    ADD CONSTRAINT finding_attachments_finding_id_fkey FOREIGN KEY (finding_id) REFERENCES public.findings(id);


--
-- Name: finding_attachments finding_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.finding_attachments
    ADD CONSTRAINT finding_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: finding_revisions finding_revisions_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.finding_revisions
    ADD CONSTRAINT finding_revisions_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: finding_revisions finding_revisions_finding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.finding_revisions
    ADD CONSTRAINT finding_revisions_finding_id_fkey FOREIGN KEY (finding_id) REFERENCES public.findings(id);


--
-- Name: findings findings_engagement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES public.engagements(id);


--
-- Name: findings findings_source_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT findings_source_upload_id_fkey FOREIGN KEY (source_upload_id) REFERENCES public.scan_uploads(id);


--
-- Name: findings fk_findings_reviewed_by_users; Type: FK CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.findings
    ADD CONSTRAINT fk_findings_reviewed_by_users FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: knowledge_entries knowledge_entries_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.knowledge_entries
    ADD CONSTRAINT knowledge_entries_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: knowledge_entries knowledge_entries_source_engagement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.knowledge_entries
    ADD CONSTRAINT knowledge_entries_source_engagement_id_fkey FOREIGN KEY (source_engagement_id) REFERENCES public.engagements(id);


--
-- Name: knowledge_entries knowledge_entries_source_finding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.knowledge_entries
    ADD CONSTRAINT knowledge_entries_source_finding_id_fkey FOREIGN KEY (source_finding_id) REFERENCES public.findings(id);


--
-- Name: scan_uploads scan_uploads_engagement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.scan_uploads
    ADD CONSTRAINT scan_uploads_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES public.engagements(id);


--
-- Name: scan_uploads scan_uploads_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.scan_uploads
    ADD CONSTRAINT scan_uploads_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: auditforge
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- PostgreSQL database dump complete
--

\unrestrict r5p9odc2egFj0KNjgA2kbJKbImERPhikKTKUz9Lzay3X2SscVO0H1yE3utnU0Ad

